package fulguris.activity

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.InputDevice
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.isVisible
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import fulguris.AppTheme
import fulguris.BuildConfig
import fulguris.R
import fulguris.chrome.ChromeAccountDialog
import fulguris.chrome.ChromeAiChatDialog
import fulguris.chrome.ChromePreferences
import fulguris.chrome.ChromeTabGroupsAndSwitcher
import fulguris.database.history.HistoryRepository
import fulguris.di.DatabaseScheduler
import fulguris.di.configPrefs
import fulguris.extensions.applyWindowInsets
import fulguris.search.SearchEngineProvider
import fulguris.settings.fragment.ResponsiveSettingsFragment
import io.reactivex.Scheduler
import javax.inject.Inject

const val FRAGMENT_CLASS_NAME = "FRAGMENT"

@AndroidEntryPoint
class SettingsActivity : ThemedSettingsActivity() {

    lateinit var responsive: ResponsiveSettingsFragment

    @Inject lateinit var searchEngineProvider: SearchEngineProvider
    @Inject lateinit var historyRepository: HistoryRepository
    @Inject @field:DatabaseScheduler lateinit var databaseScheduler: Scheduler

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        if ((event.source and InputDevice.SOURCE_CLASS_JOYSTICK) != 0) {
            return false
        }
        return super.dispatchGenericMotionEvent(event)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        responsive = ResponsiveSettingsFragment()

        setupTopBar()
        setupSearchFilter()
        setupCards()
        refreshDynamicValues()
        applyWindowInsets()
    }

    override fun onResume() {
        super.onResume()
        refreshDynamicValues()
    }

    fun updateTitleOnLayout(aGoingBack: Boolean = false) {
    }

    private fun setupTopBar() {
        findViewById<ImageButton>(R.id.btn_settings_back)?.setOnClickListener {
            finish()
        }
        findViewById<ImageButton>(R.id.btn_settings_help)?.setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("Help & feedback")
                .setMessage(
                    "Chrome Interface Browser (${BuildConfig.VERSION_NAME})\n\n" +
                        "• Tap your account card under 'You and Google' to sign in or change your username.\n" +
                        "• Tap 'Ask Gemini · Open AI (BYOK)' to configure your own API key.\n" +
                        "• Use 'Search engine' and 'Address bar' under Basics to customize navigation."
                )
                .setPositiveButton("OK", null)
                .show()
        }
    }

    private fun setupSearchFilter() {
        val searchEdit = findViewById<EditText>(R.id.et_search_settings) ?: return
        val filterableCards = listOf(
            R.id.card_account_login to "you and google account username login profile email",
            R.id.card_google_services to "google services sync discover search suggestions",
            R.id.card_search_engine to "search engine google duckduckgo brave bing startpage",
            R.id.card_address_bar to "address bar top bottom toolbar omnibox",
            R.id.card_privacy_security to "privacy and security cookies do not track clear browsing data history cache",
            R.id.card_safety_check to "safety check security https",
            R.id.card_default_browser to "default browser app",
            R.id.card_autofill_passwords to "autofill and passwords save forms",
            R.id.card_homepage_ntp to "homepage new tab page customize discover feed shortcuts",
            R.id.card_ai_assistant to "ask gemini ai mode api key openrouter openai llm",
            R.id.card_accessibility to "theme accessibility dark mode zoom adblock",
            R.id.card_about_chrome to "about chrome version webview"
        )

        searchEdit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val query = s?.toString()?.trim()?.lowercase() ?: ""
                filterableCards.forEach { (id, keywords) ->
                    findViewById<View>(id)?.isVisible = query.isEmpty() || keywords.contains(query)
                }
            }
        })
    }

    private fun setupCards() {
        findViewById<View>(R.id.card_account_login)?.setOnClickListener {
            ChromeAccountDialog.show(this) {
                refreshDynamicValues()
            }
        }

        findViewById<View>(R.id.card_google_services)?.setOnClickListener {
            val items = arrayOf(
                "Show Discover news feed on New Tab Page",
                "Show Shortcuts on New Tab Page",
                "Send Do Not Track request"
            )
            val checked = booleanArrayOf(
                ChromePreferences.isDiscoverEnabled(this),
                ChromePreferences.isShortcutsEnabled(this),
                userPreferences.doNotTrackEnabled
            )
            MaterialAlertDialogBuilder(this)
                .setTitle("Google services")
                .setMultiChoiceItems(items, checked) { _, which, isChecked ->
                    checked[which] = isChecked
                }
                .setPositiveButton("Save") { _, _ ->
                    ChromePreferences.setDiscoverEnabled(this, checked[0])
                    ChromePreferences.setShortcutsEnabled(this, checked[1])
                    userPreferences.doNotTrackEnabled = checked[2]
                    refreshDynamicValues()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        findViewById<View>(R.id.card_search_engine)?.setOnClickListener {
            val engines = searchEngineProvider.provideAllSearchEngines()
            val names = engines.mapIndexed { idx, engine ->
                if (idx == 0) "Custom Search URL" else getString(engine.titleRes)
            }.toTypedArray()
            val currentChoice = userPreferences.searchChoice.coerceIn(0, names.lastIndex)

            MaterialAlertDialogBuilder(this)
                .setTitle("Search engine")
                .setSingleChoiceItems(names, currentChoice) { dialog, which ->
                    userPreferences.searchChoice = which
                    refreshDynamicValues()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        findViewById<View>(R.id.card_address_bar)?.setOnClickListener {
            val options = arrayOf("Top", "Bottom")
            val currentIdx = if (configPrefs.toolbarsBottom) 1 else 0
            MaterialAlertDialogBuilder(this)
                .setTitle("Address bar")
                .setSingleChoiceItems(options, currentIdx) { dialog, which ->
                    configPrefs.toolbarsBottom = (which == 1)
                    refreshDynamicValues()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        findViewById<View>(R.id.card_privacy_security)?.setOnClickListener {
            val options = arrayOf(
                "Accept cookies",
                "Send 'Do Not Track' request",
                "Clear history on exit",
                "Clear cookies on exit",
                "Clear cache on exit"
            )
            val checked = booleanArrayOf(
                userPreferences.cookiesEnabled,
                userPreferences.doNotTrackEnabled,
                userPreferences.clearHistoryExitEnabled,
                userPreferences.clearCookiesExitEnabled,
                userPreferences.clearCacheExit
            )
            MaterialAlertDialogBuilder(this)
                .setTitle("Privacy and security")
                .setMultiChoiceItems(options, checked) { _, which, isChecked ->
                    checked[which] = isChecked
                }
                .setPositiveButton("Save") { _, _ ->
                    userPreferences.cookiesEnabled = checked[0]
                    userPreferences.doNotTrackEnabled = checked[1]
                    userPreferences.clearHistoryExitEnabled = checked[2]
                    userPreferences.clearCookiesExitEnabled = checked[3]
                    userPreferences.clearCacheExit = checked[4]
                }
                .setNeutralButton("Delete browsing data...") { _, _ ->
                    ChromeTabGroupsAndSwitcher.showDeleteBrowsingDataDialog(
                        this,
                        historyRepository,
                        databaseScheduler
                    )
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        findViewById<View>(R.id.card_safety_check)?.setOnClickListener {
            val cookiesOk = if (userPreferences.cookiesEnabled) "Standard cookies enabled (Incognito isolated)" else "All cookies blocked"
            val dntOk = if (userPreferences.doNotTrackEnabled) "Enabled" else "Off"
            val keyStatus = if (ChromePreferences.getAiApiKey(this).isNotEmpty()) "Stored locally in private app preferences" else "No API key stored"
            MaterialAlertDialogBuilder(this)
                .setTitle("Safety check")
                .setMessage(
                    "✓ Safe Browsing & WebView Sandboxing: Active\n\n" +
                        "✓ Cookies & Site Data: $cookiesOk\n\n" +
                        "✓ Do Not Track Header: $dntOk\n\n" +
                        "✓ BYOK AI Key Storage: $keyStatus"
                )
                .setPositiveButton("Done", null)
                .show()
        }

        findViewById<View>(R.id.card_default_browser)?.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
            } catch (_: Exception) {
                Toast.makeText(this, "Open Android Settings > Apps > Default apps to set default browser", Toast.LENGTH_LONG).show()
            }
        }

        findViewById<View>(R.id.card_autofill_passwords)?.setOnClickListener {
            val options = arrayOf(
                "Save passwords and form data",
                "Enable WebRTC media support",
                "Allow websites to open pop-up windows"
            )
            val checked = booleanArrayOf(
                userPreferences.savePasswordsEnabled,
                userPreferences.webRtcEnabled,
                userPreferences.popupsEnabled
            )
            MaterialAlertDialogBuilder(this)
                .setTitle("Autofill and passwords")
                .setMultiChoiceItems(options, checked) { _, which, isChecked ->
                    checked[which] = isChecked
                }
                .setPositiveButton("Save") { _, _ ->
                    userPreferences.savePasswordsEnabled = checked[0]
                    userPreferences.webRtcEnabled = checked[1]
                    userPreferences.popupsEnabled = checked[2]
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        findViewById<View>(R.id.card_homepage_ntp)?.setOnClickListener {
            ChromeTabGroupsAndSwitcher.showCustomizeNtpDialog(this) {
                refreshDynamicValues()
            }
        }

        findViewById<View>(R.id.card_ai_assistant)?.setOnClickListener {
            ChromeAiChatDialog.showApiKeyConfigDialog(this) {
                refreshDynamicValues()
            }
        }

        findViewById<View>(R.id.card_accessibility)?.setOnClickListener {
            val themes = AppTheme.values()
            val themeLabels = arrayOf(
                "System Default (Material You)",
                "Light (Warm Olive Sand)",
                "White",
                "Dark",
                "Black (AMOLED)"
            )
            val currentIdx = themes.indexOf(userPreferences.useTheme).coerceIn(0, themeLabels.lastIndex)
            MaterialAlertDialogBuilder(this)
                .setTitle("Theme and Accessibility")
                .setSingleChoiceItems(themeLabels, currentIdx) { dialog, which ->
                    userPreferences.useTheme = themes[which]
                    dialog.dismiss()
                    recreate()
                }
                .setNeutralButton(if (userPreferences.adBlockEnabled) "Disable AdBlock" else "Enable AdBlock") { _, _ ->
                    userPreferences.adBlockEnabled = !userPreferences.adBlockEnabled
                    Toast.makeText(
                        this,
                        if (userPreferences.adBlockEnabled) "AdBlock enabled" else "AdBlock disabled",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        findViewById<View>(R.id.card_about_chrome)?.setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("About Chrome Browser")
                .setMessage(
                    "Version: ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})\n" +
                        "Engine: Android System WebView (Blink / Chromium)\n" +
                        "UI: Material 3 Expressive Chrome Interface\n" +
                        "AI Assistant: Open-Source BYOK Chat\n" +
                        "Discover Feed: Open-Source RSS & JSON Aggregator"
                )
                .setPositiveButton("OK", null)
                .show()
        }
    }

    private fun refreshDynamicValues() {
        val avatarView = findViewById<TextView>(R.id.tv_account_avatar)
        avatarView?.text = ChromePreferences.getAvatarInitial(this)
        avatarView?.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor(ChromePreferences.getAvatarColor(this@SettingsActivity)))
        }
        findViewById<TextView>(R.id.tv_account_name)?.text = ChromePreferences.getUsername(this)
        findViewById<TextView>(R.id.tv_account_email)?.text = ChromePreferences.getEmailOrHandle(this)

        val engines = searchEngineProvider.provideAllSearchEngines()
        val choice = userPreferences.searchChoice.coerceIn(0, engines.lastIndex)
        val engineName = if (choice == 0) "Custom" else getString(engines[choice].titleRes)
        findViewById<TextView>(R.id.tv_search_engine_value)?.text = engineName

        findViewById<TextView>(R.id.tv_address_bar_value)?.text =
            if (configPrefs.toolbarsBottom) "Bottom" else "Top"

        val provider = ChromePreferences.getAiProvider(this).uppercase()
        val model = ChromePreferences.getAiModel(this)
        val hasKey = ChromePreferences.getAiApiKey(this).isNotEmpty()
        findViewById<TextView>(R.id.tv_ai_assistant_value)?.text =
            if (hasKey) "$provider · $model (Key configured)" else "$provider · $model (Tap to add API key)"

        findViewById<TextView>(R.id.tv_about_version)?.text =
            "Version ${BuildConfig.VERSION_NAME} · Android WebView Engine"
    }
}
