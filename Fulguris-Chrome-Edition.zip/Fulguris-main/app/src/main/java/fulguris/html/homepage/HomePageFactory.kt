package fulguris.html.homepage

import android.app.Application
import dagger.Reusable
import fulguris.App
import fulguris.R
import fulguris.chrome.ChromeDiscoverFeedManager
import fulguris.chrome.ChromePreferences
import fulguris.constant.FILE
import fulguris.html.HtmlPageFactory
import fulguris.search.SearchEngineProvider
import fulguris.settings.preferences.UserPreferences
import io.reactivex.Single
import java.io.File
import java.io.FileWriter
import javax.inject.Inject

@Reusable
class HomePageFactory @Inject constructor(
    private val application: Application,
    private val searchEngineProvider: SearchEngineProvider,
    private val homePageReader: HomePageReader,
    private var userPreferences: UserPreferences
) : HtmlPageFactory {

    override fun buildPage(): Single<String> = Single
        .just(searchEngineProvider.provideSearchEngine())
        .map { (iconUrl, queryUrl, _) ->
            App.setLocale()
            val theme = ChromePreferences.getNtpTheme(application)
            val palette = when (theme) {
                "ocean_blue" -> NtpPalette("#E6EEF8", "#F7FAFF", "#D3E2F4", "#101C2B", "#4A5C70", "#1A73E8")
                "lavender" -> NtpPalette("#EFEBF7", "#FAF8FF", "#DFD7F0", "#1D192B", "#544C68", "#6750A4")
                "forest_green" -> NtpPalette("#E6EFE8", "#F6FBF7", "#D2E4D6", "#111F15", "#44594A", "#2E6B3E")
                "dark_slate" -> NtpPalette("#1C1D21", "#282A2F", "#33363D", "#E8EAED", "#9AA0A6", "#A8C7FA")
                else -> NtpPalette("#ECE9DF", "#FAF8F2", "#DEDAD0", "#1E1B13", "#4B4739", "#4A5D23")
            }

            ChromeDiscoverFeedManager.refreshFeedAsync(application)

            val shortcutsHtml = if (ChromePreferences.isShortcutsEnabled(application)) buildShortcutsHtml() else ""
            val tipsHtml = if (ChromePreferences.isChromeTipsVisible(application)) buildChromeTipsHtml() else ""
            val discoverHtml = if (ChromePreferences.isDiscoverEnabled(application)) buildDiscoverHtml() else ""

            val rawTemplate = homePageReader.provideHtml()
            rawTemplate
                .replace("\${TITLE}", application.getString(R.string.home))
                .replace("\${backgroundColor}", palette.bgMain)
                .replace("\${cardColor}", palette.bgCard)
                .replace("\${searchBarColor}", palette.bgPill)
                .replace("\${searchBarTextColor}", palette.textPrimary)
                .replace("\${secondaryTextColor}", palette.textSecondary)
                .replace("\${accent}", palette.accent)
                .replace("\${IMAGE}", iconUrl)
                .replace("\${BASE_URL}", queryUrl)
                .replace("\${SHORTCUTS_HTML}", shortcutsHtml)
                .replace("\${CHROME_TIPS_HTML}", tipsHtml)
                .replace("\${DISCOVER_HTML}", discoverHtml)
        }
        .map { content -> Pair(createHomePage(), content) }
        .doOnSuccess { (page, content) ->
            FileWriter(page, false).use {
                it.write(content)
            }
        }
        .map { (page, _) -> "$FILE$page" }

    private fun buildShortcutsHtml(): String {
        val shortcuts = ChromePreferences.getShortcuts(application)
        val sb = StringBuilder()
        sb.append("<div class=\"surface-card\"><div class=\"shortcuts-scroll\">")
        shortcuts.forEach { item ->
            val safeTitle = escapeHtml(item.title)
            val safeUrl = escapeHtml(item.url)
            val safeBadge = escapeHtml(item.badgeText)
            sb.append(
                "<a class=\"shortcut-item\" href=\"$safeUrl\">" +
                    "<div class=\"shortcut-circle-outer\">" +
                    "<div class=\"shortcut-circle-inner\" style=\"background-color:${item.badgeColor};\">$safeBadge</div>" +
                    "</div>" +
                    "<div class=\"shortcut-label\">$safeTitle</div>" +
                    "</a>"
            )
        }
        sb.append("</div></div>")
        return sb.toString()
    }

    private fun buildChromeTipsHtml(): String {
        return """
            <div class="surface-card">
                <div class="tips-header">Chrome tips</div>
                <div class="tips-body">
                    <div class="tips-badge">
                        <svg width="34" height="34" viewBox="0 0 24 24" fill="#4A5D23">
                            <path d="M18 4V3c0-.55-.45-1-1-1H5c-.55 0-1 .45-1 1v4c0 .55.45 1 1 1h12c.55 0 1-.45 1-1V6h1v4H9v11c0 .55.45 1 1 1h2c.55 0 1-.45 1-1v-9h8V4h-3zm-2 2H6V4h10v2z"/>
                        </svg>
                    </div>
                    <div class="tips-text-col">
                        <h3 class="tips-title">Customize your homepage</h3>
                        <p class="tips-desc">Make Chrome your own with custom colors and images for your homepage</p>
                    </div>
                </div>
                <div class="tips-actions">
                    <button type="button" class="try-now-btn" onclick="triggerCustomizeNtp()">Try it now</button>
                </div>
            </div>
        """.trimIndent()
    }

    private fun buildDiscoverHtml(): String {
        val articles = ChromePreferences.getCachedDiscoverArticles(application)
        val sb = StringBuilder()
        articles.forEachIndexed { idx, article ->
            val safeTitle = escapeHtml(article.title)
            val safeUrl = escapeHtml(article.url)
            val safeSource = escapeHtml(article.source)
            val safeTime = escapeHtml(article.timeAgo)
            val badgeInitial = safeSource.take(2).uppercase()

            if (idx == 1 || article.imageUrl == "landscape_banner") {
                sb.append(
                    """
                    <a class="discover-card" href="$safeUrl">
                        <div class="discover-wide-banner"></div>
                        <h3 class="discover-headline" style="margin-bottom:12px;">$safeTitle</h3>
                        <div class="discover-footer">
                            <div class="discover-source-wrap">
                                <span class="discover-source-badge" style="background-color:#4A5D23;">$badgeInitial</span>
                                <span>$safeSource · $safeTime</span>
                            </div>
                            <div class="discover-actions">
                                <button type="button" class="discover-icon-btn" onclick="return triggerShare('$safeTitle', '$safeUrl', event)">
                                    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92 1.61 0 2.92-1.31 2.92-2.92s-1.31-2.92-2.92-2.92z"/></svg>
                                </button>
                                <span>⋮</span>
                            </div>
                        </div>
                    </a>
                    """.trimIndent()
                )
            } else {
                val thumbHtml = if (article.imageUrl.startsWith("http")) {
                    "<img class=\"discover-thumb\" src=\"${escapeHtml(article.imageUrl)}\" alt=\"\" />"
                } else {
                    "<div class=\"discover-thumb\">${escapeHtml(article.category.take(6))}</div>"
                }
                sb.append(
                    """
                    <a class="discover-card" href="$safeUrl">
                        <div class="discover-top-row">
                            <h3 class="discover-headline">$safeTitle</h3>
                            $thumbHtml
                        </div>
                        <div class="discover-footer">
                            <div class="discover-source-wrap">
                                <span class="discover-source-badge">$badgeInitial</span>
                                <span>$safeSource · $safeTime</span>
                            </div>
                            <div class="discover-actions">
                                <button type="button" class="discover-icon-btn" onclick="return triggerShare('$safeTitle', '$safeUrl', event)">
                                    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92 1.61 0 2.92-1.31 2.92-2.92s-1.31-2.92-2.92-2.92z"/></svg>
                                </button>
                                <span>⋮</span>
                            </div>
                        </div>
                    </a>
                    """.trimIndent()
                )
            }
        }
        sb.append(
            """
            <div class="refresh-feed-bar">
                <button type="button" class="refresh-feed-btn" onclick="triggerRefreshFeed()">↻ Refresh Open-Source Discover Feed</button>
            </div>
            """.trimIndent()
        )
        return sb.toString()
    }

    private fun escapeHtml(input: String): String =
        input
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&#39;")

    fun createHomePage() = File(application.filesDir, FILENAME)

    private data class NtpPalette(
        val bgMain: String,
        val bgCard: String,
        val bgPill: String,
        val textPrimary: String,
        val textSecondary: String,
        val accent: String
    )

    companion object {
        const val FILENAME = "homepage.html"
    }
}
