/*
 * The contents of this file are subject to the Common Public Attribution License Version 1.0.
 * (the "License"); you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at:
 * https://github.com/Slion/Fulguris/blob/main/LICENSE.CPAL-1.0.
 * The License is based on the Mozilla Public License Version 1.1, but Sections 14 and 15 have been
 * added to cover use of software over a computer network and provide for limited attribution for
 * the Original Developer. In addition, Exhibit A has been modified to be consistent with Exhibit B.
 *
 * Software distributed under the License is distributed on an "AS IS" basis, WITHOUT WARRANTY OF
 * ANY KIND, either express or implied. See the License for the specific language governing rights
 * and limitations under the License.
 *
 * The Original Code is Fulguris.
 *
 * The Original Developer is the Initial Developer.
 * The Initial Developer of the Original Code is Stéphane Lenclud.
 *
 * All portions of the code written by Stéphane Lenclud are Copyright © 2020 Stéphane Lenclud.
 * All Rights Reserved.
 */

package fulguris

import fulguris.activity.IncognitoActivity
import fulguris.activity.SettingsActivity
import fulguris.activity.SplashActivity
import fulguris.database.bookmark.BookmarkExporter
import fulguris.database.bookmark.BookmarkRepository
import fulguris.di.DatabaseScheduler
import fulguris.settings.preferences.DeveloperPreferences
import fulguris.settings.preferences.LandscapePreferences
import fulguris.settings.preferences.PortraitPreferences
import fulguris.settings.preferences.UserPreferences
import fulguris.utils.installMultiDex
import android.annotation.SuppressLint
import android.app.Activity
import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.webkit.WebView
import com.jakewharton.threetenabp.AndroidThreeTen
import dagger.hilt.android.HiltAndroidApp
import fulguris.settings.Config
import fulguris.settings.preferences.ConfigurationPreferences
import io.reactivex.Scheduler
import io.reactivex.plugins.RxJavaPlugins
import timber.log.Timber
import javax.inject.Inject
import kotlin.system.exitProcess


@SuppressLint("StaticFieldLeak")
lateinit var app: App

@HiltAndroidApp
class App : Application(), SharedPreferences.OnSharedPreferenceChangeListener,
    Application.ActivityLifecycleCallbacks {

    @Inject internal lateinit var developerPreferences: DeveloperPreferences
    @Inject internal lateinit var userPreferences: UserPreferences
    @Inject internal lateinit var portraitPreferences: PortraitPreferences
    @Inject internal lateinit var landscapePreferences: LandscapePreferences
    @Inject internal lateinit var bookmarkModel: BookmarkRepository
    @Inject @DatabaseScheduler
    internal lateinit var databaseScheduler: Scheduler

    // Provide global access to current configuration preferences
    internal var configPreferences: ConfigurationPreferences? = null

    //@Inject internal lateinit var buildInfo: BuildInfo

    // Used to be able to tell when our application was just started
    var justStarted: Boolean = true
    //Ugly way to pass our domain around for settings
    var domain: String = ""
    //Ugly way to pass our config around for settings
    var config = Config("")

    /**
     * Our app can runs in a different process when using the incognito activity.
     * This tells us which process it is.
     * However this is initialized after the activity creation when running on versions before Android 9.
     */
    var incognito = false
        private set(value) {
            if (value) {
                Timber.d("Incognito app process")
            }
            field = value
        }

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        // We only need to install that multi DEX library when not doing minify code optimization, typically in debug, and on devices below API level 21.
        // In fact from API level 21 and above Android Runtime (ART) is used rather than deprecated Dalvik.
        // Since ART has multi DEX support built-in we don't need to install that DEX library from API level 21 and above.
        // See: https://github.com/Slion/Fulguris/issues/116
        if (BuildConfig.DEBUG && Build.VERSION.SDK_INT < 21) {
            installMultiDex(context = base)
        }
    }


    /**
     * Setup Timber log engine according to user preferences
     */
    private fun plantTimberLogs() {

        // Update Timber
        if (userPreferences.logs) {
            Timber.uprootAll()
            Timber.plant(TimberLevelTree(userPreferences.logLevel.value))
        } else {
            Timber.uprootAll()
        }

        // Test our logs
        Timber.v("Log verbose")
        Timber.d("Log debug")
        Timber.i("Log info")
        Timber.w("Log warn")
        Timber.e("Log error")
        // We disabled that as we don't want our process to terminate
        // Though it did not terminate the app in debug configuration on Huawei P30 Pro - Android 10
        //Timber.wtf("Log assert")
    }


    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
        Timber.v("onActivityCreated")
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            if (activity is IncognitoActivity) {
                // Needed as the process check we use below does not work before Android 9
                incognito = true
            }
        }
    }

    override fun onActivityStarted(activity: Activity) {
        Timber.v("onActivityStarted")
    }

    override fun onActivityResumed(activity: Activity) {
        Timber.v("onActivityResumed")
        resumedActivity = activity
    }

    override fun onActivityPaused(activity: Activity) {
        Timber.v("onActivityPaused")
        resumedActivity = null
    }

    override fun onActivityStopped(activity: Activity) {
        Timber.v("onActivityStopped")
    }

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {
        Timber.v("onActivitySaveInstanceState")
    }

    override fun onActivityDestroyed(activity: Activity) {
        Timber.v("onActivityDestroyed")
        fulguris.utils.MemoryLeakUtils.clearNextServedView(activity, this@App)
    }


    /**
     *
     */
    override fun onCreate() {
        app = this
        registerActivityLifecycleCallbacks(this)
        // SL: Use this to debug when launched from another app for instance
        //Debug.waitForDebugger()
        super.onCreate()
        // No need to unregister I suppose cause this is for the life time of the application anyway
        userPreferences.preferences.registerOnSharedPreferenceChangeListener(this)

        plantTimberLogs()
        Timber.v("onCreate")

        AndroidThreeTen.init(this);

        if (BuildConfig.DEBUG) {
            /*
            StrictMode.setThreadPolicy(StrictMode.ThreadPolicy.Builder()
                .detectAll()
                .penaltyLog()
                .build())
            StrictMode.setVmPolicy(StrictMode.VmPolicy.Builder()
                .detectAll()
                .penaltyLog()
                .build())
             */
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            if (getProcessName() == "$packageName:incognito") {
                incognito = true
                WebView.setDataDirectorySuffix("incognito")
            }
        }

        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()

        Thread.setDefaultUncaughtExceptionHandler { thread, ex ->
            if (userPreferences.crashLogs) {
                fulguris.utils.FileUtils.writeCrashToStorage(ex)
            }

            if (defaultHandler != null) {
                defaultHandler.uncaughtException(thread, ex)
            } else {
                exitProcess(2)
            }
        }

	    // TODO: Remove that once we are done with ReactiveX
        RxJavaPlugins.setErrorHandler { throwable: Throwable? ->
            if (userPreferences.crashLogs && throwable != null) {
                fulguris.utils.FileUtils.writeCrashToStorage(throwable)
                throw throwable
            }
        }

        // Apply locale
        val requestLocale = fulguris.locale.LocaleUtils.requestedLocale(userPreferences.locale)
        fulguris.locale.LocaleUtils.updateLocale(this, requestLocale)

        // Import default bookmarks if none present
        // Now doing this synchronously as on fast devices it could result in not showing the bookmarks on first start
        if (bookmarkModel.count()==0L) {
            Timber.d("Create default bookmarks")
            val assetsBookmarks = BookmarkExporter.importBookmarksFromAssets(this@App)
            bookmarkModel.addBookmarkList(assetsBookmarks)
        }

        if (BuildConfig.DEBUG) {
            WebView.setWebContentsDebuggingEnabled(true)
        }

        // Set up the correct activity alias based on the incoming view action preference
        fulguris.utils.ActivityAliasManager.updateEnabledActivity(this, userPreferences.incomingViewAction)

        // Log build and device information
        logBuildInfo()

        // Register the "Stealth" and "Settings" dynamic app shortcuts (mirrors LeakCanary's
        // "Leaks" shortcut). Re-registered at every launch so they survive launcher DB resets.
        registerShortcuts(this)
    }

    /**
     * Registers the app's dynamic shortcuts (a "Stealth" incognito-browser entry and a
     * "Settings" entry) so they show up as entries in the launcher's long-press context menu
     * (instead of additional launcher icons).
     *
     * This mirrors exactly how LeakCanary's "Leaks" shortcut works (see
     * `leakcanary.LeakCanaryAndroidInternalUtils.addLeakActivityDynamicShortcut`): it uses
     * `ShortcutManager.addDynamicShortcuts` with a `ShortcutInfo.Builder` that sets **both**
     * `setActivity(...)` and `setIntent(...)` — the launcher needs `setActivity` to know which
     * app to bind the shortcut to, and the intent must carry an action (a known Android quirk).
     * It is re-registered at every app launch (from [onCreate]), which is precisely why
     * LeakCanary's shortcut survives launcher-DB resets and reinstalls: it is simply re-added.
     *
     * No user interaction is required (unlike `requestPinShortcut`). Each shortcut is
     * idempotent: it is skipped when already registered.
     */
    internal fun registerShortcuts(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N_MR1) {
            return
        }
        val shortcutManager = context.getSystemService(SHORTCUT_SERVICE) as? ShortcutManager ?: return
        val component = ComponentName(context.packageName, SplashActivity::class.java.name)
        // The "Stealth" incognito-browser entry (not available while already in incognito mode).
        // Both shortcuts use adaptive icons (colored background + white glyph): a plain
        // transparent glyph gets a white circular backdrop painted behind it by Samsung One
        // UI's Quick-Options popup, but an adaptive icon fills the circle with its own
        // background so that never shows through (and it renders identically on other
        // launchers, e.g. Honor, which don't add a backdrop).
        if (!incognito) {
            addShortcut(context, shortcutManager, component, "incognito",
                getString(R.string.action_incognito), R.mipmap.ic_launcher_incognito,
                Intent(context, IncognitoActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                    // The shortcut intent must carry an action (Android quirk — see LeakCanary).
                    action = Intent.ACTION_VIEW
                })
        }
        // Settings opens the app's settings screen, using the matching settings adaptive icon.
        addShortcut(context, shortcutManager, component, "settings",
            getString(R.string.settings), R.mipmap.ic_launcher_settings,
            Intent(context, SettingsActivity::class.java).apply {
                action = Intent.ACTION_VIEW
            })
    }

    /**
     * Adds a single dynamic shortcut bound to the launcher icon's own component ([component] —
     * [SplashActivity], which carries the LAUNCHER intent-filter). One UI groups dynamic
     * shortcuts by the launcher target and only shows shortcuts whose activity matches the
     * icon, so [component] must be the launcher activity even when the [intent] opens a
     * different one; `setActivity` only controls grouping. Skips when the shortcut with [id]
     * is already registered (pinned or dynamic).
     */
    private fun addShortcut(context: Context, shortcutManager: ShortcutManager, component: ComponentName,
                            id: String, label: String, iconRes: Int, intent: Intent) {
        try {
            if (shortcutManager.pinnedShortcuts.any { it.id == id } ||
                shortcutManager.dynamicShortcuts.any { it.id == id }
            ) {
                return
            }
            val shortcut = ShortcutInfo.Builder(context, id)
                .setShortLabel(label)
                .setLongLabel(label)
                .setIcon(Icon.createWithResource(context, iconRes))
                .setActivity(component)
                .setIntent(intent)
                .build()
            if (!shortcutManager.addDynamicShortcuts(listOf(shortcut))) {
                Timber.w("Could not add the '$id' dynamic shortcut")
            }
        } catch (e: Exception) {
            Timber.w(e, "Could not register the '$id' shortcut")
        }
    }

    /**
     * Logs comprehensive build, device, and environment information for debugging.
     */
    private fun logBuildInfo() {
        // App package and version
        try {
            val packageInfo = packageManager.getPackageInfo(packageName, 0)
            val versionName = packageInfo.versionName ?: "unknown"
            val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                packageInfo.longVersionCode
            } else {
                @Suppress("DEPRECATION")
                packageInfo.versionCode.toLong()
            }
            Timber.i("App: package=$packageName, versionName=$versionName, versionCode=$versionCode, flavor=${BuildConfig.FLAVOR}, buildType=${BuildConfig.BUILD_TYPE}")
        } catch (e: Exception) {
            Timber.w(e, "Failed to read package info")
        }

        // Android OS version
        val securityPatch = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Build.VERSION.SECURITY_PATCH
        } else {
            "N/A"
        }
        Timber.i("Android: SDK=${Build.VERSION.SDK_INT}, release=${Build.VERSION.RELEASE}, securityPatch=$securityPatch, codename=${Build.VERSION.CODENAME}")

        // Device information
        Timber.i("Device: brand=${Build.BRAND}, manufacturer=${Build.MANUFACTURER}, model=${Build.MODEL}, product=${Build.PRODUCT}, device=${Build.DEVICE}")
        Timber.i("Build: id=${Build.ID}, display=${Build.DISPLAY}, fingerprint=${Build.FINGERPRINT}")
        Timber.i("Hardware: board=${Build.BOARD}, hardware=${Build.HARDWARE}, supportedAbis=${Build.SUPPORTED_ABIS.joinToString(",")}")

        // Locale
        val locale = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            resources.configuration.locales.get(0)
        } else {
            @Suppress("DEPRECATION")
            resources.configuration.locale
        }
        Timber.i("Locale: ${locale.toLanguageTag()} (${locale.displayName})")

        // Screen metrics
        try {
            val displayMetrics = resources.displayMetrics
            Timber.i("Screen: width=${displayMetrics.widthPixels}px, height=${displayMetrics.heightPixels}px, density=${displayMetrics.density}, densityDpi=${displayMetrics.densityDpi}")
        } catch (e: Exception) {
            Timber.w(e, "Failed to read screen metrics")
        }

        // Memory info
        val runtime = Runtime.getRuntime()
        val maxMemory = runtime.maxMemory() / (1024 * 1024)
        val totalMemory = runtime.totalMemory() / (1024 * 1024)
        val freeMemory = runtime.freeMemory() / (1024 * 1024)
        Timber.i("Memory: max=${maxMemory}MB, total=${totalMemory}MB, free=${freeMemory}MB")

        // Process info
        Timber.i("Process: incognito=$incognito, debuggable=${BuildConfig.DEBUG}")
    }


    companion object {

        // Used to track current activity
        // Apparently we take care of not leaking it above
        @SuppressLint("StaticFieldLeak")
        var resumedActivity: Activity? = null
            private set

        /**
         * Used to get current activity context in order to access current theme.
         */
        fun currentContext() : Context {
            return resumedActivity
                ?: app
        }

        /**
         * Was needed to patch issue with Homepage displaying system language when user selected another language
         */
        fun setLocale() {
            val requestLocale = fulguris.locale.LocaleUtils.requestedLocale(app.userPreferences.locale)
            fulguris.locale.LocaleUtils.updateLocale(app, requestLocale)
        }

    }

    /**
     *
     */
    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
        if (key == getString(R.string.pref_key_log_level) || key == getString(R.string.pref_key_logs)) {
            // Update Timber according to changed preferences
            plantTimberLogs()
        }

        if (key == getString(R.string.pref_key_incoming_view_action)) {
            // Update which activity/alias is enabled for handling VIEW intents
            fulguris.utils.ActivityAliasManager.updateEnabledActivity(this, userPreferences.incomingViewAction)
        }
    }

}
