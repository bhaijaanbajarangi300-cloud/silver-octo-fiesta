package fulguris.chrome

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.dialog.MaterialAlertDialogBuilder

object ChromeAccountDialog {

    private val AVATAR_COLORS = listOf(
        "#4A5C68" to "Slate",
        "#4A5D23" to "Olive",
        "#1A73E8" to "Blue",
        "#7B1FA2" to "Purple",
        "#00796B" to "Teal",
        "#C62828" to "Crimson"
    )

    fun show(context: Context, onAccountUpdated: () -> Unit) {
        val density = context.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(16), dp(24), dp(8))
        }

        var selectedColor = ChromePreferences.getAvatarColor(context)
        val avatarPreview = TextView(context).apply {
            val size = dp(64)
            layoutParams = LinearLayout.LayoutParams(size, size).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                bottomMargin = dp(12)
            }
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 26f
            paint.isFakeBoldText = true
            text = ChromePreferences.getAvatarInitial(context)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor(selectedColor))
            }
        }
        root.addView(avatarPreview)

        val statusLabel = TextView(context).apply {
            text = if (ChromePreferences.isLoggedIn(context)) {
                "Signed in as ${ChromePreferences.getUsername(context)}"
            } else {
                "Not signed in (Guest)"
            }
            gravity = Gravity.CENTER
            textSize = 14f
            setPadding(0, 0, 0, dp(16))
        }
        root.addView(statusLabel)

        val usernameLabel = TextView(context).apply {
            text = "Username / Display Name"
            textSize = 12f
            paint.isFakeBoldText = true
        }
        root.addView(usernameLabel)

        val usernameInput = EditText(context).apply {
            hint = "Enter username (e.g. Nullimw Nullime)"
            setText(ChromePreferences.getUsername(context))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
        }
        root.addView(usernameInput)

        val emailLabel = TextView(context).apply {
            text = "Email or Handle"
            textSize = 12f
            paint.isFakeBoldText = true
            setPadding(0, dp(10), 0, 0)
        }
        root.addView(emailLabel)

        val emailInput = EditText(context).apply {
            hint = "e.g. user@example.com or @username"
            setText(ChromePreferences.getEmailOrHandle(context))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        }
        root.addView(emailInput)

        val passwordLabel = TextView(context).apply {
            text = "Password / Local Passcode (Optional)"
            textSize = 12f
            paint.isFakeBoldText = true
            setPadding(0, dp(10), 0, 0)
        }
        root.addView(passwordLabel)

        val passwordInput = EditText(context).apply {
            hint = "••••••••"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        root.addView(passwordInput)

        val colorLabel = TextView(context).apply {
            text = "Avatar Badge Color"
            textSize = 12f
            paint.isFakeBoldText = true
            setPadding(0, dp(12), 0, dp(6))
        }
        root.addView(colorLabel)

        val colorRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        AVATAR_COLORS.forEach { (hex, _) ->
            val swatch = TextView(context).apply {
                val sz = dp(34)
                layoutParams = LinearLayout.LayoutParams(sz, sz).apply {
                    marginEnd = dp(8)
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor(hex))
                }
                setOnClickListener {
                    selectedColor = hex
                    avatarPreview.background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(Color.parseColor(selectedColor))
                    }
                }
            }
            colorRow.addView(swatch)
        }
        root.addView(colorRow)

        MaterialAlertDialogBuilder(context)
            .setTitle("Account Login")
            .setView(root)
            .setPositiveButton("Sign in / Save") { _, _ ->
                val newUser = usernameInput.text.toString().trim().ifEmpty { "User" }
                val newEmail = emailInput.text.toString().trim().ifEmpty { "${newUser.lowercase().replace(" ", "")}@local" }
                ChromePreferences.setUsername(context, newUser)
                ChromePreferences.setEmailOrHandle(context, newEmail)
                ChromePreferences.setAvatarColor(context, selectedColor)
                ChromePreferences.setLoggedIn(context, true)
                onAccountUpdated()
                Toast.makeText(context, "Signed in as $newUser", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton(if (ChromePreferences.isLoggedIn(context)) "Sign out" else "Cancel") { _, _ ->
                if (ChromePreferences.isLoggedIn(context)) {
                    ChromePreferences.setLoggedIn(context, false)
                    ChromePreferences.setUsername(context, "Guest")
                    ChromePreferences.setEmailOrHandle(context, "Tap to sign in with username")
                    onAccountUpdated()
                    Toast.makeText(context, "Signed out", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }
}
