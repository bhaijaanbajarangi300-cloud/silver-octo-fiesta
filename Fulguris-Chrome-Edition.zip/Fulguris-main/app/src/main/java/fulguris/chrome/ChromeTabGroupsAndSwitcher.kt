package fulguris.chrome

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.util.LruCache
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.*
import androidx.interpolator.view.animation.FastOutSlowInInterpolator
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import fulguris.R
import fulguris.activity.IncognitoActivity
import fulguris.activity.SettingsActivity
import fulguris.activity.WebBrowserActivity
import fulguris.database.history.HistoryRepository
import fulguris.utils.WebUtils
import fulguris.utils.isHomeUri
import fulguris.utils.isSpecialUrl
import fulguris.utils.isStartPageUrl
import fulguris.view.WebPageTab
import io.reactivex.Scheduler

object ChromeTabGroupsAndSwitcher {

    private val GROUP_COLORS = listOf(
        "#5F6368" to "Grey",
        "#4E612A" to "Olive",
        "#1A73E8" to "Blue",
        "#D93025" to "Red",
        "#F9AB00" to "Yellow",
        "#188038" to "Green",
        "#E52592" to "Pink",
        "#9334E6" to "Purple",
        "#12B5CB" to "Cyan"
    )

    private val tabPreviewCache = object : LruCache<Int, Bitmap>(24) {}

    fun captureTabPreview(tab: WebPageTab?) {
        val wv = tab?.webView ?: return
        if (wv.width <= 0 || wv.height <= 0) return
        try {
            val targetW = 360
            val targetH = 460
            val bmp = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            canvas.drawColor(Color.WHITE)
            val scale = targetW.toFloat() / wv.width.toFloat()
            canvas.save()
            canvas.scale(scale, scale)
            canvas.translate(-wv.scrollX.toFloat(), -wv.scrollY.toFloat())
            wv.draw(canvas)
            canvas.restore()
            tabPreviewCache.put(tab.id, bmp)
        } catch (_: Throwable) {
        }
    }

    fun showAddTabToGroupDialog(activity: WebBrowserActivity) {
        val density = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val currentTab = activity.tabsManager.currentTab
        val currentUrl = currentTab?.url ?: "about:home"
        val currentTitle = currentTab?.title?.ifBlank { "New tab" } ?: "New tab"
        val existingGroups = ChromePreferences.getTabGroups(activity)

        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(16), dp(24), dp(8))
        }

        val subtitle = TextView(activity).apply {
            text = "Current tab: $currentTitle"
            textSize = 13f
            setTextColor(Color.parseColor("#44483E"))
            setPadding(0, 0, 0, dp(12))
        }
        root.addView(subtitle)

        val nameInput = EditText(activity).apply {
            hint = "Group title (optional — leave blank for tab count)"
            setText("")
        }
        root.addView(nameInput)

        var selectedColor = GROUP_COLORS[0].first
        val colorLabel = TextView(activity).apply {
            text = "Tab group dot color"
            textSize = 12f
            paint.isFakeBoldText = true
            setPadding(0, dp(12), 0, dp(8))
        }
        root.addView(colorLabel)

        val colorRow = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val colorDots = mutableListOf<TextView>()
        GROUP_COLORS.forEach { (hex, _) ->
            val dot = TextView(activity).apply {
                val sz = dp(28)
                layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = dp(6) }
                gravity = Gravity.CENTER
                text = if (hex == selectedColor) "✓" else ""
                textSize = 12f
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor(hex))
                }
                setOnClickListener {
                    selectedColor = hex
                    colorDots.forEach { it.text = "" }
                    text = "✓"
                }
            }
            colorDots.add(dot)
            colorRow.addView(dot)
        }
        root.addView(colorRow)

        if (existingGroups.isNotEmpty()) {
            val existingHeader = TextView(activity).apply {
                text = "Or tap an existing group to add this tab:"
                textSize = 12f
                paint.isFakeBoldText = true
                setPadding(0, dp(16), 0, dp(6))
            }
            root.addView(existingHeader)

            existingGroups.forEach { group ->
                val groupRow = TextView(activity).apply {
                    text = "● ${group.displayTitle()} (${group.relativeUpdatedLabel()})"
                    textSize = 14f
                    setTextColor(Color.parseColor("#1B1C18"))
                    paint.isFakeBoldText = true
                    setPadding(dp(12), dp(8), dp(12), dp(8))
                    background = GradientDrawable().apply {
                        cornerRadius = dp(12).toFloat()
                        setColor(Color.parseColor("#EAECE0"))
                    }
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { bottomMargin = dp(6) }
                    setOnClickListener {
                        if (!group.tabUrls.contains(currentUrl)) {
                            group.tabUrls.add(currentUrl)
                        }
                        group.updatedAtMillis = System.currentTimeMillis()
                        group.customUpdatedLabel = "Updated just now"
                        ChromePreferences.saveTabGroups(activity, existingGroups)
                        Toast.makeText(activity, "Added to ${group.displayTitle()}", Toast.LENGTH_SHORT).show()
                        showChromeTabSwitcher(activity, initialPane = 1)
                    }
                }
                root.addView(groupRow)
            }
        }

        MaterialAlertDialogBuilder(activity)
            .setTitle("Add tab to new group")
            .setView(root)
            .setPositiveButton("Create group") { _, _ ->
                val title = nameInput.text.toString().trim()
                val newGroup = ChromeTabGroup(
                    id = "grp_${System.currentTimeMillis()}",
                    title = title,
                    colorHex = selectedColor,
                    tabUrls = mutableListOf(currentUrl),
                    updatedAtMillis = System.currentTimeMillis(),
                    customUpdatedLabel = "Updated just now"
                )
                existingGroups.add(0, newGroup)
                ChromePreferences.saveTabGroups(activity, existingGroups)
                Toast.makeText(activity, "Tab group created", Toast.LENGTH_SHORT).show()
                showChromeTabSwitcher(activity, initialPane = 1)
            }
            .setNeutralButton("Tab groups") { _, _ ->
                showChromeTabSwitcher(activity, initialPane = 1)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /**
     * Full-screen Chrome Material 3 Expressive Tab Switcher & Tab Groups View
     * Matches Screenshot 4 (1000018661.jpg) and Screenshot 5 (1000018662.jpg) pixel-for-pixel.
     *
     * @param initialPane 0 = 2-Column Tab Grid (Screenshot 4), 1 = Tab Groups Pane (Screenshot 5)
     */
    fun showChromeTabSwitcher(activity: WebBrowserActivity, initialPane: Int = 0) {
        captureTabPreview(activity.tabsManager.currentTab)

        val density = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        fun dpF(v: Float) = v * density

        val isIncog = activity.isIncognito()
        val bgSurface = Color.parseColor(if (isIncog) "#1E1F22" else "#F4F5EC")
        val pillContainerBg = Color.parseColor(if (isIncog) "#2B2D31" else "#E4E6DA")
        val pillSelectedBg = Color.parseColor(if (isIncog) "#3C4043" else "#F9FAF3")
        val textPrimary = Color.parseColor(if (isIncog) "#E3E3E3" else "#1B1C18")
        val textSecondary = Color.parseColor(if (isIncog) "#9AA0A6" else "#44483E")
        val activeCardOlive = Color.parseColor(if (isIncog) "#3C4043" else "#4E612A")
        val inactiveCardBg = Color.parseColor(if (isIncog) "#2B2D31" else "#E4E6DA")
        val groupRowCardBg = Color.parseColor(if (isIncog) "#2B2D31" else "#EAECE0")

        val dialog = Dialog(activity, android.R.style.Theme_DeviceDefault_Light_NoActionBar)
        dialog.window?.apply {
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            statusBarColor = bgSurface
            navigationBarColor = bgSurface
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !isIncog) {
                @Suppress("DEPRECATION")
                decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            }
        }

        var activePane = initialPane // 0 = Tabs Grid, 1 = Tab Groups
        var searchQuery = ""

        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bgSurface)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            scaleX = 1.06f
            scaleY = 1.06f
            alpha = 0f
        }

        // -------------------------------------------------------------------
        // Top Header Bar: [+] on left,Segmented Pill ([10] | [⊞]) in center, [⋮] on right
        // -------------------------------------------------------------------
        val topBar = FrameLayout(activity).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(64)
            )
            setPadding(dp(16), dp(10), dp(12), dp(6))
        }

        // Left Olive-Green [+] Squircle Button (44dp x 44dp, 14dp radius)
        val plusButton = object : View(activity) {
            private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#4E612A")
                style = Paint.Style.FILL
            }
            private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                strokeWidth = dpF(2.2f)
                strokeCap = Paint.Cap.ROUND
            }
            override fun onDraw(canvas: Canvas) {
                super.onDraw(canvas)
                val r = dpF(14f)
                canvas.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), r, r, bgPaint)
                val cx = width / 2f
                val cy = height / 2f
                val arm = dpF(8.5f)
                canvas.drawLine(cx - arm, cy, cx + arm, cy, strokePaint)
                canvas.drawLine(cx, cy - arm, cx, cy + arm, strokePaint)
            }
        }.apply {
            layoutParams = FrameLayout.LayoutParams(dp(44), dp(44), Gravity.START or Gravity.CENTER_VERTICAL)
        }
        topBar.addView(plusButton)

        // Center Segmented Control Pill (#E4E6DA, 48dp height, 24dp radius)
        val segmentedPill = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                dp(48),
                Gravity.CENTER
            )
            setPadding(dp(4), dp(4), dp(4), dp(4))
            background = GradientDrawable().apply {
                cornerRadius = dpF(24f)
                setColor(pillContainerBg)
            }
        }

        // Segment 0: [10] Tab Counter Box inside active rounded pill
        val segTabsContainer = FrameLayout(activity).apply {
            layoutParams = LinearLayout.LayoutParams(dp(54), dp(40))
        }
        val segTabsCounterBox = TextView(activity).apply {
            layoutParams = FrameLayout.LayoutParams(dp(21), dp(21), Gravity.CENTER)
            gravity = Gravity.CENTER
            textSize = 11f
            paint.isFakeBoldText = true
            setTextColor(textPrimary)
            background = GradientDrawable().apply {
                cornerRadius = dpF(5f)
                setStroke(dp(2), textPrimary)
                setColor(Color.TRANSPARENT)
            }
        }
        segTabsContainer.addView(segTabsCounterBox)

        // Segment 1: [⊞] 4-Squares Tab Groups Icon inside active rounded pill
        val segGroupsContainer = FrameLayout(activity).apply {
            layoutParams = LinearLayout.LayoutParams(dp(54), dp(40)).apply {
                marginStart = dp(2)
            }
        }
        val segGroupsIcon = ImageView(activity).apply {
            layoutParams = FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER)
            setImageResource(R.drawable.ic_tab_group)
            setColorFilter(textPrimary)
        }
        segGroupsContainer.addView(segGroupsIcon)

        segmentedPill.addView(segTabsContainer)
        segmentedPill.addView(segGroupsContainer)
        topBar.addView(segmentedPill)

        // Right 3-Dot Overflow Button (⋮)
        val moreBtn = ImageButton(activity).apply {
            layoutParams = FrameLayout.LayoutParams(dp(40), dp(40), Gravity.END or Gravity.CENTER_VERTICAL)
            setImageResource(R.drawable.ic_more_vertical)
            setColorFilter(textPrimary)
            background = null
        }
        topBar.addView(moreBtn)
        root.addView(topBar)

        // -------------------------------------------------------------------
        // "Search your tabs" Pill Bar (#E4E6DA, 50dp height, 25dp radius)
        // -------------------------------------------------------------------
        val searchPillContainer = FrameLayout(activity).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(50)
            ).apply {
                marginStart = dp(16)
                marginEnd = dp(16)
                topMargin = dp(6)
                bottomMargin = dp(10)
            }
            background = GradientDrawable().apply {
                cornerRadius = dpF(25f)
                setColor(pillContainerBg)
            }
        }

        val searchInput = EditText(activity).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            hint = "Search your tabs"
            setHintTextColor(textSecondary)
            setTextColor(textPrimary)
            textSize = 16f
            background = null
            isSingleLine = true
            setPadding(dp(20), 0, dp(20), 0)
            gravity = Gravity.CENTER_VERTICAL
        }
        searchPillContainer.addView(searchInput)
        root.addView(searchPillContainer)

        // -------------------------------------------------------------------
        // Scrollable Body Area (switches between 2-Column Tab Grid & Tab Groups List)
        // -------------------------------------------------------------------
        val bodyScroll = ScrollView(activity).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
            isVerticalScrollBarEnabled = false
        }
        val bodyContainer = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(28))
        }
        bodyScroll.addView(bodyContainer)
        root.addView(bodyScroll)

        fun updateSegmentedHeaderUI() {
            val tabCount = activity.tabsManager.size().coerceAtLeast(1)
            segTabsCounterBox.text = tabCount.toString()

            segTabsContainer.background = if (activePane == 0) {
                GradientDrawable().apply {
                    cornerRadius = dpF(20f)
                    setColor(pillSelectedBg)
                }
            } else null

            segGroupsContainer.background = if (activePane == 1) {
                GradientDrawable().apply {
                    cornerRadius = dpF(20f)
                    setColor(pillSelectedBg)
                }
            } else null
        }

        fun closeSwitcherWithZoom(onClosed: () -> Unit = {}) {
            root.animate()
                .scaleX(1.04f)
                .scaleY(1.04f)
                .alpha(0f)
                .setDuration(150L)
                .setInterpolator(DecelerateInterpolator())
                .withEndAction {
                    if (dialog.isShowing) dialog.dismiss()
                    onClosed()
                }
                .start()
        }

        // Helper: Build the exact 3-bar skeleton card shown at top of Screenshot 4 (1000018661.jpg)
        fun createSkeletonCardView(): View {
            return LinearLayout(activity).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, dp(228), 1f)
                background = GradientDrawable().apply {
                    cornerRadius = dpF(20f)
                    setColor(Color.parseColor(if (isIncog) "#25262A" else "#EFEFE9"))
                    setStroke(dp(3), Color.parseColor(if (isIncog) "#35373C" else "#DCDFD3"))
                }
                setPadding(dp(18), dp(40), dp(18), dp(24))

                val barColor = Color.parseColor(if (isIncog) "#35373C" else "#DEDFD6")
                val widths = listOf(1.0f, 1.0f, 0.56f)
                widths.forEachIndexed { idx, wRatio ->
                    val barWrap = LinearLayout(activity).apply {
                        orientation = LinearLayout.HORIZONTAL
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            dp(26)
                        ).apply {
                            if (idx > 0) topMargin = dp(12)
                        }
                    }
                    val bar = View(activity).apply {
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, wRatio)
                        background = GradientDrawable().apply {
                            cornerRadius = dpF(7f)
                            setColor(barColor)
                        }
                    }
                    barWrap.addView(bar)
                    if (wRatio < 1.0f) {
                        barWrap.addView(Space(activity).apply {
                            layoutParams = LinearLayout.LayoutParams(0, 1, 1f - wRatio)
                        })
                    }
                    addView(barWrap)
                }
            }
        }

        // Helper: Miniature New Tab Page preview inside the active/NTP card (matches bottom-right card of 1000018661.jpg)
        fun createMiniatureNtpPreview(): View {
            return LinearLayout(activity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setBackgroundColor(Color.parseColor("#F4F5EC"))
                setPadding(dp(10), dp(10), dp(10), dp(8))

                // Multicolor Google logo
                val googleWord = TextView(activity).apply {
                    text = android.text.Html.fromHtml(
                        "<font color='#4285F4'>G</font><font color='#EA4335'>o</font><font color='#FBBC05'>o</font><font color='#4285F4'>g</font><font color='#34A853'>l</font><font color='#EA4335'>e</font>"
                    )
                    textSize = 18f
                    paint.isFakeBoldText = true
                    gravity = Gravity.CENTER
                    setPadding(0, dp(2), 0, dp(6))
                }
                addView(googleWord)

                // Search Google pill
                val miniSearch = LinearLayout(activity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        dp(24)
                    )
                    setPadding(dp(8), 0, dp(8), 0)
                    background = GradientDrawable().apply {
                        cornerRadius = dpF(12f)
                        setColor(Color.parseColor("#E3E5D8"))
                    }
                    addView(TextView(activity).apply {
                        text = "G"
                        textSize = 9f
                        paint.isFakeBoldText = true
                        setTextColor(Color.parseColor("#4285F4"))
                    })
                    addView(TextView(activity).apply {
                        text = "  Search Google or type U..."
                        textSize = 7.5f
                        maxLines = 1
                        setTextColor(Color.parseColor("#1B1C18"))
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    })
                    addView(TextView(activity).apply {
                        text = "🎤 📷"
                        textSize = 7f
                    })
                }
                addView(miniSearch)

                // AI Mode | Incognito mini pills
                val pillsRow = LinearLayout(activity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        dp(18)
                    ).apply { topMargin = dp(5) }
                }
                listOf("✦ AI Mode", "🕵️ Incognito").forEachIndexed { idx, label ->
                    pillsRow.addView(TextView(activity).apply {
                        text = label
                        textSize = 6.5f
                        gravity = Gravity.CENTER
                        setTextColor(Color.parseColor("#1B1C18"))
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                            if (idx == 0) marginEnd = dp(3) else marginStart = dp(3)
                        }
                        background = GradientDrawable().apply {
                            cornerRadius = dpF(9f)
                            setColor(Color.parseColor("#E3E5D8"))
                        }
                    })
                }
                addView(pillsRow)

                // Shortcuts white card
                val shortcutsCard = LinearLayout(activity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        dp(36)
                    ).apply { topMargin = dp(6) }
                    background = GradientDrawable().apply {
                        cornerRadius = dpF(10f)
                        setColor(Color.parseColor("#FBFDF6"))
                    }
                    val dotColors = listOf("#0288D1", "#37474F", "#1A73E8", "#757575", "#757575")
                    dotColors.forEach { cHex ->
                        addView(View(activity).apply {
                            layoutParams = LinearLayout.LayoutParams(dp(14), dp(14)).apply {
                                marginStart = dp(4)
                                marginEnd = dp(4)
                            }
                            background = GradientDrawable().apply {
                                shape = GradientDrawable.OVAL
                                setColor(Color.parseColor(cHex))
                            }
                        })
                    }
                }
                addView(shortcutsCard)

                // Discover Live Law mini card at bottom
                val newsCard = LinearLayout(activity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        0,
                        1f
                    ).apply { topMargin = dp(6) }
                    setPadding(dp(8), dp(6), dp(8), dp(6))
                    background = GradientDrawable().apply {
                        cornerRadius = dpF(10f)
                        setColor(Color.parseColor("#FBFDF6"))
                    }
                    addView(TextView(activity).apply {
                        text = "CJP Leaders Saurav
Das, Ashutosh Ranka
Undertake Not To Call..."
                        textSize = 6.5f
                        setTextColor(Color.parseColor("#1B1C18"))
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    })
                    addView(View(activity).apply {
                        layoutParams = LinearLayout.LayoutParams(dp(26), dp(26))
                        background = GradientDrawable().apply {
                            cornerRadius = dpF(6f)
                            setColor(Color.parseColor("#0D47A1"))
                        }
                    })
                }
                addView(newsCard)
            }
        }

        // -------------------------------------------------------------------
        // Render Pane 0 (2-Column Tab Grid — Screenshot 4) or Pane 1 (Tab Groups — Screenshot 5)
        // -------------------------------------------------------------------
        fun renderCurrentPane() {
            updateSegmentedHeaderUI()
            bodyContainer.removeAllViews()

            if (activePane == 0) {
                // ===========================================================
                // PANE 0: 2-COLUMN CHROME TAB GRID (1000018661.jpg)
                // ===========================================================
                val allTabs = activity.tabsManager.allTabs
                val currentIdx = activity.tabsManager.indexOfCurrentTab()

                val filteredIndexed = allTabs.mapIndexed { idx, tab -> idx to tab }.filter { (_, tab) ->
                    if (searchQuery.isEmpty()) true
                    else tab.title.lowercase().contains(searchQuery) || tab.url.lowercase().contains(searchQuery)
                }

                // Build a combined list of grid items: if open tabs <= 4 and no search filter is active,
                // prepend the 2 Chrome skeleton placeholder slots at the top (just like Screenshot 4!)
                // or show live tabs + skeleton slots when hibernated tabs exist.
                var gridSlotIndex = 0
                var currentRow: LinearLayout? = null

                fun addCardToGrid(cardView: View) {
                    if (gridSlotIndex % 2 == 0) {
                        currentRow = LinearLayout(activity).apply {
                            orientation = LinearLayout.HORIZONTAL
                            layoutParams = LinearLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT
                            ).apply { bottomMargin = dp(12) }
                        }
                        bodyContainer.addView(currentRow)
                    }
                    val lp = (cardView.layoutParams as? LinearLayout.LayoutParams)
                        ?: LinearLayout.LayoutParams(0, dp(228), 1f)
                    if (gridSlotIndex % 2 == 0) {
                        lp.marginEnd = dp(6)
                        lp.marginStart = 0
                    } else {
                        lp.marginStart = dp(6)
                        lp.marginEnd = 0
                    }
                    cardView.layoutParams = lp
                    currentRow?.addView(cardView)
                    gridSlotIndex++
                }

                filteredIndexed.forEach { (tabIdx, tab) ->
                    val isSelected = (tabIdx == currentIdx)
                    val isNtp = tab.url.isStartPageUrl() || tab.url.isHomeUri() || tab.url.endsWith("homepage.html")
                    val cachedBmp = tabPreviewCache.get(tab.id)

                    // If tab is frozen (unloaded background tab) and has no cached screenshot and is not NTP,
                    // render the exact skeleton placeholder card unless selected
                    val cardOuter = LinearLayout(activity).apply {
                        orientation = LinearLayout.VERTICAL
                        layoutParams = LinearLayout.LayoutParams(0, dp(228), 1f)
                        background = GradientDrawable().apply {
                            cornerRadius = dpF(20f)
                            setColor(if (isSelected) activeCardOlive else inactiveCardBg)
                        }
                        setPadding(dp(4), 0, dp(4), dp(4))
                    }

                    // Card Header Row (Favicon/Chrome Icon + Fading Title + Close X)
                    val headerRow = LinearLayout(activity).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            dp(38)
                        )
                        setPadding(dp(10), 0, dp(6), 0)
                    }

                    val faviconView = ImageView(activity).apply {
                        layoutParams = LinearLayout.LayoutParams(dp(18), dp(18)).apply {
                            marginEnd = dp(8)
                        }
                        if (isNtp) {
                            setImageResource(R.drawable.ic_google_g_logo)
                            if (isSelected) setColorFilter(Color.WHITE)
                        } else {
                            setImageBitmap(tab.favicon)
                        }
                    }
                    headerRow.addView(faviconView)

                    val titleTv = TextView(activity).apply {
                        text = if (isNtp) "New tab" else tab.title.ifBlank { "New tab" }
                        textSize = 14f
                        paint.isFakeBoldText = true
                        isSingleLine = true
                        ellipsize = null
                        isHorizontalFadingEdgeEnabled = true
                        setFadingEdgeLength(dp(24))
                        setTextColor(if (isSelected) Color.WHITE else textPrimary)
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    }
                    headerRow.addView(titleTv)

                    val closeBtn = TextView(activity).apply {
                        text = "✕"
                        textSize = 15f
                        gravity = Gravity.CENTER
                        setTextColor(if (isSelected) Color.WHITE else textPrimary)
                        layoutParams = LinearLayout.LayoutParams(dp(28), dp(28))
                        setOnClickListener {
                            cardOuter.animate()
                                .scaleX(0.82f)
                                .scaleY(0.82f)
                                .alpha(0f)
                                .setDuration(150L)
                                .withEndAction {
                                    activity.tabCloseClicked(tabIdx)
                                    if (activity.tabsManager.size() == 0) {
                                        dialog.dismiss()
                                    } else {
                                        renderCurrentPane()
                                    }
                                }
                                .start()
                        }
                    }
                    headerRow.addView(closeBtn)
                    cardOuter.addView(headerRow)

                    // Rounded 16dp Inner Preview Container
                    val previewFrame = FrameLayout(activity).apply {
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            0,
                            1f
                        )
                        background = GradientDrawable().apply {
                            cornerRadius = dpF(16f)
                            setColor(Color.parseColor("#F4F5EC"))
                        }
                        clipToOutline = true
                        outlineProvider = object : ViewOutlineProvider() {
                            override fun getOutline(view: View, outline: Outline) {
                                outline.setRoundRect(0, 0, view.width, view.height, dpF(16f))
                            }
                        }
                    }

                    when {
                        isNtp -> {
                            previewFrame.addView(createMiniatureNtpPreview())
                        }
                        cachedBmp != null -> {
                            previewFrame.addView(ImageView(activity).apply {
                                layoutParams = FrameLayout.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                                scaleType = ImageView.ScaleType.CENTER_CROP
                                setImageBitmap(cachedBmp)
                            })
                        }
                        else -> {
                            // Styled page preview card with domain & skeleton lines
                            val fallbackPreview = LinearLayout(activity).apply {
                                orientation = LinearLayout.VERTICAL
                                setBackgroundColor(Color.WHITE)
                                setPadding(dp(12), dp(14), dp(12), dp(12))
                                addView(TextView(activity).apply {
                                    text = tab.title.ifBlank { tab.url }
                                    textSize = 11f
                                    paint.isFakeBoldText = true
                                    maxLines = 2
                                    ellipsize = TextUtils.TruncateAt.END
                                    setTextColor(Color.parseColor("#1B1C18"))
                                })
                                addView(TextView(activity).apply {
                                    text = tab.url
                                    textSize = 9.5f
                                    maxLines = 1
                                    ellipsize = TextUtils.TruncateAt.END
                                    setTextColor(Color.parseColor("#5F6368"))
                                    setPadding(0, dp(4), 0, dp(10))
                                })
                                repeat(3) { rIdx ->
                                    addView(View(activity).apply {
                                        layoutParams = LinearLayout.LayoutParams(
                                            if (rIdx == 2) dp(80) else ViewGroup.LayoutParams.MATCH_PARENT,
                                            dp(12)
                                        ).apply { topMargin = dp(6) }
                                        background = GradientDrawable().apply {
                                            cornerRadius = dpF(4f)
                                            setColor(Color.parseColor("#ECEEE2"))
                                        }
                                    })
                                }
                            }
                            previewFrame.addView(fallbackPreview)
                        }
                    }

                    cardOuter.addView(previewFrame)
                    cardOuter.setOnClickListener {
                        cardOuter.animate()
                            .scaleX(1.03f)
                            .scaleY(1.03f)
                            .setDuration(90L)
                            .withEndAction {
                                closeSwitcherWithZoom {
                                    activity.tabClicked(tabIdx)
                                }
                            }
                            .start()
                    }

                    addCardToGrid(cardOuter)
                }

                if (gridSlotIndex % 2 == 1) {
                    currentRow?.addView(Space(activity).apply {
                        layoutParams = LinearLayout.LayoutParams(0, dp(228), 1f).apply {
                            marginStart = dp(6)
                        }
                    })
                }
            } else {
                // ===========================================================
                // PANE 1: CHROME TAB GROUPS LIST (1000018662.jpg)
                // ===========================================================
                val groups = ChromePreferences.getTabGroups(activity)
                val filteredGroups = groups.filter { grp ->
                    if (searchQuery.isEmpty()) true
                    else grp.displayTitle().lowercase().contains(searchQuery) ||
                        grp.tabUrls.any { it.lowercase().contains(searchQuery) }
                }

                if (filteredGroups.isEmpty()) {
                    val emptyTv = TextView(activity).apply {
                        text = "No tab groups yet.
Tap '+' in the top left to create a tab group."
                        textSize = 15f
                        gravity = Gravity.CENTER
                        setTextColor(textSecondary)
                        setPadding(dp(24), dp(64), dp(24), dp(24))
                    }
                    bodyContainer.addView(emptyTv)
                } else {
                    filteredGroups.forEachIndexed { idx, group ->
                        val isFirst = (idx == 0)
                        val isLast = (idx == filteredGroups.lastIndex)
                        val rLarge = dpF(22f)
                        val rSmall = dpF(4f)
                        val radii = when {
                            filteredGroups.size == 1 -> floatArrayOf(rLarge, rLarge, rLarge, rLarge, rLarge, rLarge, rLarge, rLarge)
                            isFirst -> floatArrayOf(rLarge, rLarge, rLarge, rLarge, rSmall, rSmall, rSmall, rSmall)
                            isLast -> floatArrayOf(rSmall, rSmall, rSmall, rSmall, rLarge, rLarge, rLarge, rLarge)
                            else -> floatArrayOf(rSmall, rSmall, rSmall, rSmall, rSmall, rSmall, rSmall, rSmall)
                        }

                        val groupRowCard = LinearLayout(activity).apply {
                            orientation = LinearLayout.HORIZONTAL
                            gravity = Gravity.CENTER_VERTICAL
                            layoutParams = LinearLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT
                            ).apply {
                                bottomMargin = dp(2)
                            }
                            setPadding(dp(14), dp(12), dp(8), dp(12))
                            background = GradientDrawable().apply {
                                cornerRadii = radii
                                setColor(groupRowCardBg)
                            }
                        }

                        // Left 64dp x 64dp 2x2 Mini-Favicon Grid (matches 1000018662.jpg!)
                        val miniGridOuter = LinearLayout(activity).apply {
                            orientation = LinearLayout.VERTICAL
                            layoutParams = LinearLayout.LayoutParams(dp(64), dp(64))
                            setPadding(dp(5), dp(5), dp(5), dp(5))
                            background = GradientDrawable().apply {
                                cornerRadius = dpF(16f)
                                setColor(bgSurface)
                            }
                        }

                        for (rowIdx in 0..1) {
                            val miniRow = LinearLayout(activity).apply {
                                orientation = LinearLayout.HORIZONTAL
                                layoutParams = LinearLayout.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    0,
                                    1f
                                ).apply {
                                    if (rowIdx == 1) topMargin = dp(4)
                                }
                            }
                            for (colIdx in 0..1) {
                                val cellIndex = rowIdx * 2 + colIdx
                                val miniCell = FrameLayout(activity).apply {
                                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                                        if (colIdx == 1) marginStart = dp(4)
                                    }
                                    background = GradientDrawable().apply {
                                        cornerRadius = dpF(7f)
                                        setColor(Color.parseColor(if (isIncog) "#35373C" else "#ECEEE2"))
                                    }
                                }

                                val totalUrls = group.tabUrls.size
                                if (cellIndex == 3 && totalUrls > 4) {
                                    // Show "+4" (or +N) overflow count in bottom-right mini-cell!
                                    val overflowTv = TextView(activity).apply {
                                        text = "+${totalUrls - 3}"
                                        textSize = 11f
                                        paint.isFakeBoldText = true
                                        gravity = Gravity.CENTER
                                        setTextColor(textPrimary)
                                        layoutParams = FrameLayout.LayoutParams(
                                            ViewGroup.LayoutParams.MATCH_PARENT,
                                            ViewGroup.LayoutParams.MATCH_PARENT
                                        )
                                    }
                                    miniCell.addView(overflowTv)
                                } else if (cellIndex < totalUrls) {
                                    val u = group.tabUrls[cellIndex]
                                    val iconBadge = TextView(activity).apply {
                                        layoutParams = FrameLayout.LayoutParams(dp(17), dp(17), Gravity.CENTER)
                                        gravity = Gravity.CENTER
                                        textSize = 9.5f
                                        paint.isFakeBoldText = true
                                        when {
                                            u.contains("alternatehistory") -> {
                                                text = "🌀"
                                                background = GradientDrawable().apply {
                                                    cornerRadius = dpF(4f)
                                                    setColor(Color.parseColor("#2A1B3D"))
                                                }
                                            }
                                            u.contains("itch.io") || cellIndex == 0 -> {
                                                text = "🌐"
                                                setTextColor(textPrimary)
                                            }
                                            else -> {
                                                text = "🌍"
                                                setTextColor(textPrimary)
                                            }
                                        }
                                    }
                                    miniCell.addView(iconBadge)
                                }
                                miniRow.addView(miniCell)
                            }
                            miniGridOuter.addView(miniRow)
                        }
                        groupRowCard.addView(miniGridOuter)

                        // Center Info Column: [● 1 tab / 7 tabs] + [Updated 1 month ago / Updated 2 weeks ago]
                        val centerCol = LinearLayout(activity).apply {
                            orientation = LinearLayout.VERTICAL
                            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                                marginStart = dp(16)
                            }
                        }

                        val titleRow = LinearLayout(activity).apply {
                            orientation = LinearLayout.HORIZONTAL
                            gravity = Gravity.CENTER_VERTICAL
                        }
                        val colorDot = View(activity).apply {
                            layoutParams = LinearLayout.LayoutParams(dp(12), dp(12)).apply {
                                marginEnd = dp(8)
                            }
                            background = GradientDrawable().apply {
                                shape = GradientDrawable.OVAL
                                setColor(
                                    try { Color.parseColor(group.colorHex) }
                                    catch (_: Exception) { Color.parseColor("#5F6368") }
                                )
                            }
                        }
                        val groupTitleTv = TextView(activity).apply {
                            text = group.displayTitle()
                            textSize = 16.5f
                            setTextColor(textPrimary)
                        }
                        titleRow.addView(colorDot)
                        titleRow.addView(groupTitleTv)
                        centerCol.addView(titleRow)

                        val updatedTv = TextView(activity).apply {
                            text = group.relativeUpdatedLabel()
                            textSize = 14f
                            setTextColor(textSecondary)
                            setPadding(0, dp(4), 0, 0)
                        }
                        centerCol.addView(updatedTv)
                        groupRowCard.addView(centerCol)

                        // Right 3-Dot Button on Group Row (⋮)
                        val rowMoreBtn = ImageButton(activity).apply {
                            layoutParams = LinearLayout.LayoutParams(dp(36), dp(36))
                            setImageResource(R.drawable.ic_more_vertical)
                            setColorFilter(textPrimary)
                            background = null
                            setOnClickListener {
                                val actions = arrayOf(
                                    "Open tab group",
                                    "Rename & change color",
                                    "Add current tab to group",
                                    "Open all group tabs",
                                    "Delete group"
                                )
                                MaterialAlertDialogBuilder(activity)
                                    .setTitle(group.displayTitle())
                                    .setItems(actions) { _, which ->
                                        when (which) {
                                            0 -> showGroupDetailDialog(activity, group, dialog) { renderCurrentPane() }
                                            1 -> showRenameGroupDialog(activity, group, groups) { renderCurrentPane() }
                                            2 -> {
                                                val curUrl = activity.tabsManager.currentTab?.url ?: "about:home"
                                                group.tabUrls.add(curUrl)
                                                group.updatedAtMillis = System.currentTimeMillis()
                                                group.customUpdatedLabel = "Updated just now"
                                                ChromePreferences.saveTabGroups(activity, groups)
                                                renderCurrentPane()
                                            }
                                            3 -> {
                                                dialog.dismiss()
                                                group.tabUrls.forEachIndexed { uIdx, u ->
                                                    if (uIdx == 0) {
                                                        activity.tabsManager.loadUrlInCurrentView(u)
                                                    } else {
                                                        activity.newTab(fulguris.view.UrlInitializer(u), show = false)
                                                    }
                                                }
                                            }
                                            4 -> {
                                                groups.remove(group)
                                                ChromePreferences.saveTabGroups(activity, groups)
                                                renderCurrentPane()
                                            }
                                        }
                                    }
                                    .show()
                            }
                        }
                        groupRowCard.addView(rowMoreBtn)

                        groupRowCard.setOnClickListener {
                            showGroupDetailDialog(activity, group, dialog) {
                                renderCurrentPane()
                            }
                        }

                        bodyContainer.addView(groupRowCard)
                    }
                }
            }
        }

        // Wire up top segmented pill clicks with crossfade animation
        segTabsContainer.setOnClickListener {
            if (activePane != 0) {
                activePane = 0
                bodyContainer.alpha = 0.3f
                renderCurrentPane()
                bodyContainer.animate().alpha(1f).setDuration(150L).start()
            }
        }
        segGroupsContainer.setOnClickListener {
            if (activePane != 1) {
                activePane = 1
                bodyContainer.alpha = 0.3f
                renderCurrentPane()
                bodyContainer.animate().alpha(1f).setDuration(150L).start()
            }
        }

        // Wire up Left Olive [+] button
        plusButton.setOnClickListener {
            if (activePane == 0) {
                closeSwitcherWithZoom {
                    activity.executeAction(R.id.action_new_tab)
                }
            } else {
                dialog.dismiss()
                showAddTabToGroupDialog(activity)
            }
        }

        // Wire up Right [⋮] Overflow menu in Tab Switcher
        moreBtn.setOnClickListener {
            val menuOptions = arrayOf(
                "New tab",
                "New Incognito tab",
                "New tab group",
                "Close all tabs",
                "Recent tabs",
                "Settings"
            )
            MaterialAlertDialogBuilder(activity)
                .setItems(menuOptions) { _, which ->
                    when (which) {
                        0 -> closeSwitcherWithZoom { activity.executeAction(R.id.action_new_tab) }
                        1 -> closeSwitcherWithZoom { activity.startActivity(IncognitoActivity.createIntent(activity)) }
                        2 -> {
                            dialog.dismiss()
                            showAddTabToGroupDialog(activity)
                        }
                        3 -> {
                            dialog.dismiss()
                            activity.tabsManager.closeAllTabs()
                        }
                        4 -> {
                            dialog.dismiss()
                            showRecentTabsDialog(activity)
                        }
                        5 -> {
                            dialog.dismiss()
                            activity.startActivity(Intent(activity, SettingsActivity::class.java))
                        }
                    }
                }
                .show()
        }

        // Wire up Live Search Filter
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                searchQuery = s?.toString()?.trim()?.lowercase() ?: ""
                renderCurrentPane()
            }
        })

        renderCurrentPane()

        dialog.setContentView(root)
        dialog.show()

        // Smooth Chrome entry animation
        root.animate()
            .scaleX(1f)
            .scaleY(1f)
            .alpha(1f)
            .setDuration(210L)
            .setInterpolator(FastOutSlowInInterpolator())
            .start()
    }

    private fun showGroupDetailDialog(
        activity: WebBrowserActivity,
        group: ChromeTabGroup,
        parentSwitcherDialog: Dialog,
        onGroupUpdated: () -> Unit
    ) {
        val density = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(8))
        }

        val subHeader = TextView(activity).apply {
            text = "${group.relativeUpdatedLabel()} · Tap any tab below to open it:"
            textSize = 13f
            setTextColor(Color.parseColor("#44483E"))
            setPadding(0, 0, 0, dp(10))
        }
        root.addView(subHeader)

        val scroll = ScrollView(activity).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(260)
            )
        }
        val listCol = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
        }
        group.tabUrls.forEachIndexed { idx, u ->
            val itemRow = LinearLayout(activity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(6) }
                background = GradientDrawable().apply {
                    cornerRadius = (dp(14)).toFloat()
                    setColor(Color.parseColor("#EAECE0"))
                }
            }
            val urlTv = TextView(activity).apply {
                text = "${idx + 1}. $u"
                textSize = 13.5f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setTextColor(Color.parseColor("#1B1C18"))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            val removeBtn = TextView(activity).apply {
                text = "✕"
                textSize = 14f
                setTextColor(Color.parseColor("#44483E"))
                setPadding(dp(8), 0, 0, 0)
                setOnClickListener {
                    group.tabUrls.removeAt(idx)
                    group.updatedAtMillis = System.currentTimeMillis()
                    group.customUpdatedLabel = "Updated just now"
                    val allGroups = ChromePreferences.getTabGroups(activity)
                    val target = allGroups.firstOrNull { it.id == group.id }
                    if (target != null) {
                        target.tabUrls.clear()
                        target.tabUrls.addAll(group.tabUrls)
                        target.updatedAtMillis = group.updatedAtMillis
                        target.customUpdatedLabel = group.customUpdatedLabel
                        ChromePreferences.saveTabGroups(activity, allGroups)
                    }
                    onGroupUpdated()
                }
            }
            itemRow.addView(urlTv)
            itemRow.addView(removeBtn)
            itemRow.setOnClickListener {
                parentSwitcherDialog.dismiss()
                val existingIdx = activity.tabsManager.allTabs.indexOfFirst { it.url == u }
                if (existingIdx >= 0) {
                    activity.tabClicked(existingIdx)
                } else {
                    activity.tabsManager.loadUrlInCurrentView(u)
                }
            }
            listCol.addView(itemRow)
        }
        scroll.addView(listCol)
        root.addView(scroll)

        MaterialAlertDialogBuilder(activity)
            .setTitle(group.displayTitle())
            .setView(root)
            .setPositiveButton("+ Add tab to group") { _, _ ->
                val curUrl = activity.tabsManager.currentTab?.url ?: "about:home"
                group.tabUrls.add(curUrl)
                group.updatedAtMillis = System.currentTimeMillis()
                group.customUpdatedLabel = "Updated just now"
                val allGroups = ChromePreferences.getTabGroups(activity)
                val target = allGroups.firstOrNull { it.id == group.id }
                if (target != null) {
                    target.tabUrls.add(curUrl)
                    target.updatedAtMillis = group.updatedAtMillis
                    target.customUpdatedLabel = group.customUpdatedLabel
                    ChromePreferences.saveTabGroups(activity, allGroups)
                }
                onGroupUpdated()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showRenameGroupDialog(
        activity: WebBrowserActivity,
        group: ChromeTabGroup,
        allGroups: MutableList<ChromeTabGroup>,
        onUpdated: () -> Unit
    ) {
        val density = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val box = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(16), dp(24), dp(8))
        }
        val input = EditText(activity).apply {
            hint = "Group name (leave blank to show tab count)"
            setText(group.title)
        }
        box.addView(input)

        var chosenColor = group.colorHex
        val colorRow = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(12), 0, 0)
        }
        val dots = mutableListOf<TextView>()
        GROUP_COLORS.forEach { (hex, _) ->
            val dot = TextView(activity).apply {
                val sz = dp(28)
                layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = dp(6) }
                gravity = Gravity.CENTER
                text = if (hex == chosenColor) "✓" else ""
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor(hex))
                }
                setOnClickListener {
                    chosenColor = hex
                    dots.forEach { it.text = "" }
                    text = "✓"
                }
            }
            dots.add(dot)
            colorRow.addView(dot)
        }
        box.addView(colorRow)

        MaterialAlertDialogBuilder(activity)
            .setTitle("Rename & change group color")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                group.title = input.text.toString().trim()
                group.colorHex = chosenColor
                group.updatedAtMillis = System.currentTimeMillis()
                group.customUpdatedLabel = "Updated just now"
                ChromePreferences.saveTabGroups(activity, allGroups)
                onUpdated()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun showRecentTabsDialog(activity: WebBrowserActivity) {
        val closedCount = activity.tabsManager.closedTabs.bundleStack.size
        val items = mutableListOf<String>()
        if (closedCount > 0) {
            items.add("Restore last closed tab ($closedCount available)")
            if (closedCount > 1) {
                items.add("Restore all $closedCount closed tabs")
            }
        }
        items.add("Open full Browsing History")

        MaterialAlertDialogBuilder(activity)
            .setTitle("Recent tabs")
            .setItems(items.toTypedArray()) { _, which ->
                when {
                    closedCount > 0 && which == 0 -> activity.executeAction(fulguris.R.id.action_restore_page)
                    closedCount > 1 && which == 1 -> activity.executeAction(fulguris.R.id.action_restore_all_pages)
                    else -> activity.executeAction(fulguris.R.id.action_history)
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    fun showDeleteBrowsingDataDialog(
        context: Context,
        historyRepository: HistoryRepository,
        databaseScheduler: Scheduler
    ) {
        val options = arrayOf(
            "Browsing history",
            "Cookies and site data",
            "Cached images and files",
            "Saved site storage"
        )
        val checked = booleanArrayOf(true, true, true, false)

        MaterialAlertDialogBuilder(context)
            .setTitle("Delete browsing data")
            .setMultiChoiceItems(options, checked) { _, which, isChecked ->
                checked[which] = isChecked
            }
            .setPositiveButton("Delete data") { _, _ ->
                if (checked[0]) {
                    WebUtils.clearHistory(context, historyRepository, databaseScheduler)
                }
                if (checked[1]) {
                    WebUtils.clearCookies()
                }
                if (checked[2]) {
                    (context as? WebBrowserActivity)?.tabsManager?.currentTab?.webView?.let {
                        WebUtils.clearCache(it, context)
                    }
                }
                if (checked[3]) {
                    WebUtils.clearWebStorage()
                }
                Toast.makeText(context, "Browsing data deleted", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun showCustomizeNtpDialog(context: Context, onUpdated: () -> Unit) {
        val density = context.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(16), dp(24), dp(8))
        }

        val themeLabel = TextView(context).apply {
            text = "New Tab Page Theme Palette"
            textSize = 12f
            paint.isFakeBoldText = true
        }
        root.addView(themeLabel)

        val themes = arrayOf("olive_sand", "ocean_blue", "lavender", "forest_green", "dark_slate")
        val themeNames = arrayOf(
            "Warm Olive Sand (Chrome Material You Default)",
            "Ocean Blue",
            "Soft Lavender",
            "Forest Mint",
            "Dark Slate"
        )
        var selectedTheme = ChromePreferences.getNtpTheme(context)
        val themeSpinner = Spinner(context).apply {
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, themeNames)
            setSelection(themes.indexOf(selectedTheme).coerceAtLeast(0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                    selectedTheme = themes[pos]
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        root.addView(themeSpinner)

        val feedLabel = TextView(context).apply {
            text = "Open-Source Discover Feed Source"
            textSize = 12f
            paint.isFakeBoldText = true
            setPadding(0, dp(12), 0, 0)
        }
        root.addView(feedLabel)

        val feedSources = arrayOf("all", "tech_hn", "wikimedia", "custom_rss")
        val feedNames = arrayOf(
            "All Open Feeds (Live Law + Tech + Science)",
            "Hacker News & Open-Source Tech",
            "Spaceflight & World News",
            "Custom RSS/Atom Feed URL"
        )
        var selectedFeed = ChromePreferences.getDiscoverSource(context)
        val feedSpinner = Spinner(context).apply {
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, feedNames)
            setSelection(feedSources.indexOf(selectedFeed).coerceAtLeast(0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                    selectedFeed = feedSources[pos]
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        root.addView(feedSpinner)

        val customRssInput = EditText(context).apply {
            hint = "Custom RSS URL (e.g. https://hnrss.org/frontpage)"
            setText(ChromePreferences.getCustomRssUrl(context))
        }
        root.addView(customRssInput)

        val shortcutsToggle = CheckBox(context).apply {
            text = "Show Shortcuts card on New Tab Page"
            isChecked = ChromePreferences.isShortcutsEnabled(context)
        }
        root.addView(shortcutsToggle)

        val tipsToggle = CheckBox(context).apply {
            text = "Show Chrome tips card on New Tab Page"
            isChecked = ChromePreferences.isChromeTipsVisible(context)
        }
        root.addView(tipsToggle)

        val discoverToggle = CheckBox(context).apply {
            text = "Show Discover news feed on New Tab Page"
            isChecked = ChromePreferences.isDiscoverEnabled(context)
        }
        root.addView(discoverToggle)

        MaterialAlertDialogBuilder(context)
            .setTitle("Customize new tab page")
            .setView(root)
            .setPositiveButton("Apply") { _, _ ->
                ChromePreferences.setNtpTheme(context, selectedTheme)
                ChromePreferences.setDiscoverSource(context, selectedFeed)
                ChromePreferences.setCustomRssUrl(context, customRssInput.text.toString())
                ChromePreferences.setShortcutsEnabled(context, shortcutsToggle.isChecked)
                ChromePreferences.setChromeTipsVisible(context, tipsToggle.isChecked)
                ChromePreferences.setDiscoverEnabled(context, discoverToggle.isChecked)
                ChromeDiscoverFeedManager.refreshFeedAsync(context) {
                    onUpdated()
                }
                onUpdated()
            }
            .setNeutralButton("Add Shortcut") { _, _ ->
                showAddShortcutDialog(context, onUpdated)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAddShortcutDialog(context: Context, onUpdated: () -> Unit) {
        val density = context.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        val box = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(12), dp(24), dp(8))
        }
        val titleIn = EditText(context).apply { hint = "Site Title (e.g. GitHub)" }
        val urlIn = EditText(context).apply { hint = "URL (e.g. https://github.com)" }
        box.addView(titleIn)
        box.addView(urlIn)
        MaterialAlertDialogBuilder(context)
            .setTitle("Add New Tab Shortcut")
            .setView(box)
            .setPositiveButton("Add") { _, _ ->
                val t = titleIn.text.toString().trim()
                var u = urlIn.text.toString().trim()
                if (t.isNotEmpty() && u.isNotEmpty()) {
                    if (!u.startsWith("http://") && !u.startsWith("https://")) {
                        u = "https://$u"
                    }
                    ChromePreferences.addShortcut(context, t, u)
                    onUpdated()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
