package fulguris.chrome

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class ChromeTabGroup(
    val id: String,
    var title: String,
    var colorHex: String,
    val tabUrls: MutableList<String> = mutableListOf(),
    var updatedAtMillis: Long = System.currentTimeMillis(),
    var customUpdatedLabel: String = ""
) {
    fun displayTitle(): String {
        val countLabel = "${tabUrls.size} ${if (tabUrls.size == 1) "tab" else "tabs"}"
        return if (title.isBlank() || title.startsWith("Group ")) {
            countLabel
        } else {
            "$title · $countLabel"
        }
    }

    fun relativeUpdatedLabel(): String {
        if (customUpdatedLabel.isNotBlank()) return customUpdatedLabel
        val diffMs = (System.currentTimeMillis() - updatedAtMillis).coerceAtLeast(0L)
        val mins = diffMs / 60_000L
        val hours = mins / 60L
        val days = hours / 24L
        val weeks = days / 7L
        val months = days / 30L
        return when {
            mins < 1L -> "Updated just now"
            mins < 60L -> "Updated ${mins}m ago"
            hours < 24L -> "Updated ${hours}h ago"
            days == 1L -> "Updated 1 day ago"
            days < 7L -> "Updated $days days ago"
            weeks == 1L -> "Updated 1 week ago"
            weeks < 4L -> "Updated $weeks weeks ago"
            months <= 1L -> "Updated 1 month ago"
            else -> "Updated $months months ago"
        }
    }
}

data class ChromeShortcutItem(
    val title: String,
    val url: String,
    val badgeText: String,
    val badgeColor: String
)

data class DiscoverArticle(
    val title: String,
    val url: String,
    val source: String,
    val timeAgo: String,
    val imageUrl: String,
    val category: String = "News"
)

object ChromePreferences {
    private const val PREFS_NAME = "chrome_ui_preferences"

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getUsername(context: Context): String =
        prefs(context).getString("account_username", "Nullimw Nullime") ?: "Nullimw Nullime"

    fun setUsername(context: Context, value: String) {
        prefs(context).edit().putString("account_username", value.trim().ifEmpty { "User" }).apply()
    }

    fun getEmailOrHandle(context: Context): String =
        prefs(context).getString("account_email", "nullimwtx654@gmail.com") ?: "nullimwtx654@gmail.com"

    fun setEmailOrHandle(context: Context, value: String) {
        prefs(context).edit().putString("account_email", value.trim()).apply()
    }

    fun isLoggedIn(context: Context): Boolean =
        prefs(context).getBoolean("account_logged_in", true)

    fun setLoggedIn(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean("account_logged_in", value).apply()
    }

    fun getAvatarColor(context: Context): String =
        prefs(context).getString("account_avatar_color", "#4A5C68") ?: "#4A5C68"

    fun setAvatarColor(context: Context, colorHex: String) {
        prefs(context).edit().putString("account_avatar_color", colorHex).apply()
    }

    fun getAvatarInitial(context: Context): String {
        if (!isLoggedIn(context)) return "?"
        val name = getUsername(context).trim()
        return if (name.isNotEmpty()) name.first().uppercaseChar().toString() else "N"
    }

    fun isIncognitoBlockThirdPartyCookies(context: Context): Boolean =
        prefs(context).getBoolean("incognito_block_3p_cookies", true)

    fun setIncognitoBlockThirdPartyCookies(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean("incognito_block_3p_cookies", enabled).apply()
    }

    fun isHttpsFirstEnabled(context: Context): Boolean =
        prefs(context).getBoolean("chrome_https_first", true)

    fun setHttpsFirstEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean("chrome_https_first", enabled).apply()
    }

    fun isSafeBrowsingEnabled(context: Context): Boolean =
        prefs(context).getBoolean("chrome_safe_browsing", true)

    fun setSafeBrowsingEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean("chrome_safe_browsing", enabled).apply()
    }

    fun getAiProvider(context: Context): String =
        prefs(context).getString("ai_provider", "gemini") ?: "gemini"

    fun setAiProvider(context: Context, provider: String) {
        prefs(context).edit().putString("ai_provider", provider).apply()
    }

    fun getAiApiKey(context: Context): String =
        prefs(context).getString("ai_api_key", "") ?: ""

    fun setAiApiKey(context: Context, key: String) {
        prefs(context).edit().putString("ai_api_key", key.trim()).apply()
    }

    fun getAiModel(context: Context): String {
        val defaultModel = when (getAiProvider(context)) {
            "gemini" -> "gemini-2.5-flash"
            "openrouter" -> "meta-llama/llama-3.3-70b-instruct:free"
            else -> "gpt-4o-mini"
        }
        val saved = prefs(context).getString("ai_model", "") ?: ""
        return saved.ifEmpty { defaultModel }
    }

    fun setAiModel(context: Context, model: String) {
        prefs(context).edit().putString("ai_model", model.trim()).apply()
    }

    fun getAiEndpoint(context: Context): String {
        val defaultEndpoint = when (getAiProvider(context)) {
            "gemini" -> "https://generativelanguage.googleapis.com/v1beta/models"
            "openrouter" -> "https://openrouter.ai/api/v1/chat/completions"
            else -> "https://api.openai.com/v1/chat/completions"
        }
        val saved = prefs(context).getString("ai_endpoint", "") ?: ""
        return saved.ifEmpty { defaultEndpoint }
    }

    fun setAiEndpoint(context: Context, endpoint: String) {
        prefs(context).edit().putString("ai_endpoint", endpoint.trim()).apply()
    }

    fun getAiIncludePageContext(context: Context): Boolean =
        prefs(context).getBoolean("ai_include_page_context", true)

    fun setAiIncludePageContext(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean("ai_include_page_context", enabled).apply()
    }

    fun getNtpTheme(context: Context): String =
        prefs(context).getString("ntp_theme", "olive_sand") ?: "olive_sand"

    fun setNtpTheme(context: Context, theme: String) {
        prefs(context).edit().putString("ntp_theme", theme).apply()
    }

    fun isDiscoverEnabled(context: Context): Boolean =
        prefs(context).getBoolean("discover_enabled", true)

    fun setDiscoverEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean("discover_enabled", enabled).apply()
    }

    fun getDiscoverSource(context: Context): String =
        prefs(context).getString("discover_source", "all") ?: "all"

    fun setDiscoverSource(context: Context, source: String) {
        prefs(context).edit().putString("discover_source", source).apply()
    }

    fun getCustomRssUrl(context: Context): String =
        prefs(context).getString("custom_rss_url", "https://hnrss.org/frontpage") ?: "https://hnrss.org/frontpage"

    fun setCustomRssUrl(context: Context, url: String) {
        prefs(context).edit().putString("custom_rss_url", url.trim()).apply()
    }

    fun isShortcutsEnabled(context: Context): Boolean =
        prefs(context).getBoolean("ntp_shortcuts_enabled", true)

    fun setShortcutsEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean("ntp_shortcuts_enabled", enabled).apply()
    }

    fun isChromeTipsVisible(context: Context): Boolean =
        prefs(context).getBoolean("ntp_chrome_tips_visible", true)

    fun setChromeTipsVisible(context: Context, visible: Boolean) {
        prefs(context).edit().putBoolean("ntp_chrome_tips_visible", visible).apply()
    }

    fun getShortcuts(context: Context): List<ChromeShortcutItem> {
        val raw = prefs(context).getString("ntp_shortcuts_json", null)
        if (!raw.isNullOrEmpty()) {
            try {
                val arr = JSONArray(raw)
                val list = mutableListOf<ChromeShortcutItem>()
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    list.add(
                        ChromeShortcutItem(
                            title = obj.optString("title", "Site"),
                            url = obj.optString("url", "https://www.google.com"),
                            badgeText = obj.optString("badgeText", "G"),
                            badgeColor = obj.optString("badgeColor", "#0288D1")
                        )
                    )
                }
                if (list.isNotEmpty()) return list
            } catch (_: Exception) {}
        }
        return listOf(
            ChromeShortcutItem("F670LV9.0", "http://192.168.1.1", "1", "#0277BD"),
            ChromeShortcutItem("Games", "https://itch.io/games/free", "🌐", "#37474F"),
            ChromeShortcutItem("Google AI S...", "https://aistudio.google.com", "✦", "#1A73E8"),
            ChromeShortcutItem("alternatehi...", "https://www.alternatehistory.com", "A", "#6D7278"),
            ChromeShortcutItem("ha...", "https://news.ycombinator.com", "H", "#6D7278")
        )
    }

    fun addShortcut(context: Context, title: String, url: String) {
        val current = getShortcuts(context).toMutableList()
        val initial = title.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "W"
        val colors = listOf("#0277BD", "#4A5D23", "#1A73E8", "#7B1FA2", "#00796B", "#C62828")
        val color = colors[current.size % colors.size]
        current.add(0, ChromeShortcutItem(title.trim(), url.trim(), initial, color))
        saveShortcuts(context, current)
    }

    fun saveShortcuts(context: Context, items: List<ChromeShortcutItem>) {
        val arr = JSONArray()
        items.forEach { item ->
            arr.put(JSONObject().apply {
                put("title", item.title)
                put("url", item.url)
                put("badgeText", item.badgeText)
                put("badgeColor", item.badgeColor)
            })
        }
        prefs(context).edit().putString("ntp_shortcuts_json", arr.toString()).apply()
    }

    fun getTabGroups(context: Context): MutableList<ChromeTabGroup> {
        val raw = prefs(context).getString("chrome_tab_groups_json", null)
        if (raw == null) {
            val seeded = getDefaultSeededTabGroups()
            saveTabGroups(context, seeded)
            return seeded
        }
        val list = mutableListOf<ChromeTabGroup>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val urlsArr = obj.optJSONArray("tabUrls") ?: JSONArray()
                val urls = mutableListOf<String>()
                for (j in 0 until urlsArr.length()) {
                    urls.add(urlsArr.getString(j))
                }
                list.add(
                    ChromeTabGroup(
                        id = obj.optString("id", "group_$i"),
                        title = obj.optString("title", ""),
                        colorHex = obj.optString("colorHex", "#5F6368"),
                        tabUrls = urls,
                        updatedAtMillis = obj.optLong("updatedAtMillis", System.currentTimeMillis()),
                        customUpdatedLabel = obj.optString("customUpdatedLabel", "")
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    private fun getDefaultSeededTabGroups(): MutableList<ChromeTabGroup> {
        val now = System.currentTimeMillis()
        return mutableListOf(
            ChromeTabGroup(
                id = "grp_seed_1",
                title = "",
                colorHex = "#5F6368",
                tabUrls = mutableListOf("https://itch.io/games/free"),
                updatedAtMillis = now - 30L * 24L * 3600_000L,
                customUpdatedLabel = "Updated 1 month ago"
            ),
            ChromeTabGroup(
                id = "grp_seed_2",
                title = "",
                colorHex = "#5F6368",
                tabUrls = mutableListOf(
                    "https://www.alternatehistory.com",
                    "https://www.alternatehistory.com/forum/",
                    "https://earth.google.com",
                    "https://aistudio.google.com",
                    "https://github.com/arcanite24/pinyon-shift",
                    "https://news.ycombinator.com",
                    "https://www.livelaw.in"
                ),
                updatedAtMillis = now - 14L * 24L * 3600_000L,
                customUpdatedLabel = "Updated 2 weeks ago"
            )
        )
    }

    fun saveTabGroups(context: Context, groups: List<ChromeTabGroup>) {
        val arr = JSONArray()
        groups.forEach { g ->
            arr.put(JSONObject().apply {
                put("id", g.id)
                put("title", g.title)
                put("colorHex", g.colorHex)
                put("updatedAtMillis", g.updatedAtMillis)
                put("customUpdatedLabel", g.customUpdatedLabel)
                val urlsArr = JSONArray()
                g.tabUrls.forEach { urlsArr.put(it) }
                put("tabUrls", urlsArr)
            })
        }
        prefs(context).edit().putString("chrome_tab_groups_json", arr.toString()).apply()
    }

    fun getCachedDiscoverArticles(context: Context): List<DiscoverArticle> {
        val raw = prefs(context).getString("cached_discover_articles", null)
        if (!raw.isNullOrEmpty()) {
            try {
                val arr = JSONArray(raw)
                val list = mutableListOf<DiscoverArticle>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        DiscoverArticle(
                            title = o.optString("title"),
                            url = o.optString("url"),
                            source = o.optString("source"),
                            timeAgo = o.optString("timeAgo", "4h"),
                            imageUrl = o.optString("imageUrl", ""),
                            category = o.optString("category", "News")
                        )
                    )
                }
                if (list.isNotEmpty()) return list
            } catch (_: Exception) {}
        }
        return getDefaultDiscoverArticles()
    }

    fun saveCachedDiscoverArticles(context: Context, articles: List<DiscoverArticle>) {
        val arr = JSONArray()
        articles.forEach { a ->
            arr.put(JSONObject().apply {
                put("title", a.title)
                put("url", a.url)
                put("source", a.source)
                put("timeAgo", a.timeAgo)
                put("imageUrl", a.imageUrl)
                put("category", a.category)
            })
        }
        prefs(context).edit().putString("cached_discover_articles", arr.toString()).apply()
    }

    fun getDefaultDiscoverArticles(): List<DiscoverArticle> = listOf(
        DiscoverArticle(
            title = "CJP Leaders Saurav Das, Ashutosh Ranka Undertake Not To Call For...",
            url = "https://www.livelaw.in/",
            source = "Live Law",
            timeAgo = "8h",
            imageUrl = "livelaw_thumb",
            category = "Legal"
        ),
        DiscoverArticle(
            title = "Open-Source Browser Engines & Material 3 Expressive Design Trends in 2026",
            url = "https://news.ycombinator.com/",
            source = "Hacker News",
            timeAgo = "3h",
            imageUrl = "landscape_banner",
            category = "Tech"
        ),
        DiscoverArticle(
            title = "Linux Kernel & Android WebView Performance Improvements Ship Globally",
            url = "https://lwn.net/",
            source = "LWN.net",
            timeAgo = "5h",
            imageUrl = "tech_thumb",
            category = "Open Source"
        ),
        DiscoverArticle(
            title = "Wikipedia Featured: Advances in Local & Bring-Your-Own-Key AI Assistants",
            url = "https://en.wikipedia.org/wiki/Main_Page",
            source = "Wikipedia",
            timeAgo = "6h",
            imageUrl = "wiki_thumb",
            category = "Science"
        )
    )
}
