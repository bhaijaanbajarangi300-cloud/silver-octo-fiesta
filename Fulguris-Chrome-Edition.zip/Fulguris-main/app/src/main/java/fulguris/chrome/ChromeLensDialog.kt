package fulguris.chrome

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder

object ChromeLensDialog {

    fun show(context: Context, onSearchQuery: (String) -> Unit) {
        val density = context.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val dialog = BottomSheetDialog(context)
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#18191C"))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setPadding(dp(20), dp(16), dp(20), dp(24))
        }

        val topBar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(16))
        }

        val closeBtn = TextView(context).apply {
            text = "✕"
            textSize = 20f
            setTextColor(Color.WHITE)
            setPadding(dp(8), dp(4), dp(16), dp(4))
            setOnClickListener { dialog.dismiss() }
        }
        topBar.addView(closeBtn)

        val titleView = TextView(context).apply {
            text = "Google Lens"
            textSize = 20f
            setTextColor(Color.WHITE)
            paint.isFakeBoldText = true
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        topBar.addView(titleView)

        val flashBadge = TextView(context).apply {
            text = "⚡ Auto"
            textSize = 13f
            setTextColor(Color.parseColor("#E8EAED"))
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#2D2F33"))
            }
            setOnClickListener {
                Toast.makeText(context, "Static Google Lens UI preview", Toast.LENGTH_SHORT).show()
            }
        }
        topBar.addView(flashBadge)
        root.addView(topBar)

        val viewfinder = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(280)
            ).apply {
                bottomMargin = dp(20)
            }
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(Color.parseColor("#23262B"))
                setStroke(dp(2), Color.parseColor("#4A5D23"))
            }
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }

        val reticleFrame = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(190), dp(170))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(Color.parseColor("#1AFFFFFF"))
                setStroke(dp(3), Color.parseColor("#D8E89E"))
            }
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }

        val sparkleIcon = TextView(context).apply {
            text = "✦"
            textSize = 32f
            setTextColor(Color.parseColor("#D8E89E"))
            gravity = Gravity.CENTER
        }
        reticleFrame.addView(sparkleIcon)

        val hintText = TextView(context).apply {
            text = "Point camera at text or objects\n(Static Lens UI)"
            textSize = 13f
            setTextColor(Color.parseColor("#E8EAED"))
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        reticleFrame.addView(hintText)
        viewfinder.addView(reticleFrame)
        root.addView(viewfinder)

        val shutterRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(20))
        }

        val galleryBtn = TextView(context).apply {
            text = "🖼️ Gallery"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(Color.parseColor("#2D2F33"))
            }
            setOnClickListener {
                Toast.makeText(context, "Static Google Lens UI — Gallery preview", Toast.LENGTH_SHORT).show()
            }
        }
        shutterRow.addView(galleryBtn)

        val shutterBtn = TextView(context).apply {
            val sz = dp(68)
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply {
                marginStart = dp(24)
                marginEnd = dp(24)
            }
            gravity = Gravity.CENTER
            text = "🔍"
            textSize = 24f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#D8E89E"))
                setStroke(dp(4), Color.WHITE)
            }
            setOnClickListener {
                val input = EditText(context).apply {
                    hint = "Enter image URL or visual query to search"
                }
                MaterialAlertDialogBuilder(context)
                    .setTitle("Search with Lens")
                    .setView(input)
                    .setPositiveButton("Search") { _, _ ->
                        val q = input.text.toString().trim()
                        if (q.isNotEmpty()) {
                            dialog.dismiss()
                            onSearchQuery(q)
                        }
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        }
        shutterRow.addView(shutterBtn)

        val ocrBtn = TextView(context).apply {
            text = "🔤 Select Text"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(Color.parseColor("#2D2F33"))
            }
            setOnClickListener {
                Toast.makeText(context, "Static Google Lens UI — OCR Mode", Toast.LENGTH_SHORT).show()
            }
        }
        shutterRow.addView(ocrBtn)
        root.addView(shutterRow)

        val modesRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val modes = listOf("Translate", "Search", "Homework")
        val modeViews = mutableListOf<TextView>()
        modes.forEachIndexed { idx, label ->
            val pill = TextView(context).apply {
                text = label
                textSize = 14f
                paint.isFakeBoldText = (idx == 1)
                setPadding(dp(20), dp(10), dp(20), dp(10))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    marginStart = dp(6)
                    marginEnd = dp(6)
                }
                val isSelected = (idx == 1)
                setTextColor(if (isSelected) Color.parseColor("#111F00") else Color.parseColor("#E8EAED"))
                background = GradientDrawable().apply {
                    cornerRadius = dp(20).toFloat()
                    setColor(if (isSelected) Color.parseColor("#D8E89E") else Color.parseColor("#2D2F33"))
                }
                setOnClickListener {
                    modeViews.forEachIndexed { j, tv ->
                        val sel = (j == idx)
                        tv.paint.isFakeBoldText = sel
                        tv.setTextColor(if (sel) Color.parseColor("#111F00") else Color.parseColor("#E8EAED"))
                        tv.background = GradientDrawable().apply {
                            cornerRadius = dp(20).toFloat()
                            setColor(if (sel) Color.parseColor("#D8E89E") else Color.parseColor("#2D2F33"))
                        }
                    }
                }
            }
            modeViews.add(pill)
            modesRow.addView(pill)
        }
        root.addView(modesRow)

        dialog.setContentView(root)
        dialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        dialog.show()
    }
}
