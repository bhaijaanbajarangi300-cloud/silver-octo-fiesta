package fulguris.chrome

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.*
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

object ChromeAiChatDialog {

    data class ChatTurn(val role: String, val text: String)

    private val conversationHistory = mutableListOf<ChatTurn>()
    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()

    fun show(
        context: Context,
        currentWebView: WebView?,
        currentPageTitle: String?,
        currentPageUrl: String?,
        initialPrompt: String? = null
    ) {
        val density = context.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val dialog = BottomSheetDialog(context)
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#ECE9DF"))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setPadding(dp(16), dp(14), dp(16), dp(16))
        }

        val headerRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(10))
        }

        val sparkleBadge = TextView(context).apply {
            val sz = dp(36)
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = dp(10) }
            gravity = Gravity.CENTER
            text = "✦"
            textSize = 18f
            setTextColor(Color.parseColor("#111F00"))
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#D8E89E"))
            }
        }
        headerRow.addView(sparkleBadge)

        val titleCol = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val headerTitle = TextView(context).apply {
            text = "Ask Gemini · Open AI (BYOK)"
            textSize = 17f
            setTextColor(Color.parseColor("#1E1B13"))
            paint.isFakeBoldText = true
        }
        val headerSub = TextView(context).apply {
            val keySet = ChromePreferences.getAiApiKey(context).isNotEmpty()
            val provider = ChromePreferences.getAiProvider(context).uppercase()
            val model = ChromePreferences.getAiModel(context)
            text = if (keySet) "$provider · $model (API Key Active)" else "Tap ⚙️ Key to configure your API key ($provider)"
            textSize = 12f
            setTextColor(Color.parseColor("#4B4739"))
        }
        titleCol.addView(headerTitle)
        titleCol.addView(headerSub)
        headerRow.addView(titleCol)

        val apiKeyBtn = TextView(context).apply {
            text = "⚙️ Key"
            textSize = 13f
            paint.isFakeBoldText = true
            setTextColor(Color.parseColor("#111F00"))
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#CBE69B"))
            }
            setOnClickListener {
                showApiKeyConfigDialog(context) {
                    val keySet = ChromePreferences.getAiApiKey(context).isNotEmpty()
                    val provider = ChromePreferences.getAiProvider(context).uppercase()
                    val model = ChromePreferences.getAiModel(context)
                    headerSub.text = if (keySet) "$provider · $model (API Key Active)" else "Tap ⚙️ Key to configure your API key ($provider)"
                }
            }
        }
        headerRow.addView(apiKeyBtn)

        val clearBtn = TextView(context).apply {
            text = "✕"
            textSize = 18f
            setTextColor(Color.parseColor("#4B4739"))
            setPadding(dp(12), dp(4), dp(4), dp(4))
            setOnClickListener { dialog.dismiss() }
        }
        headerRow.addView(clearBtn)
        root.addView(headerRow)

        val contextCheck = CheckBox(context).apply {
            text = "Include current tab context (${currentPageTitle?.take(28) ?: "New Tab"})"
            textSize = 12.5f
            setTextColor(Color.parseColor("#4B4739"))
            isChecked = ChromePreferences.getAiIncludePageContext(context)
            setOnCheckedChangeListener { _, isChecked ->
                ChromePreferences.setAiIncludePageContext(context, isChecked)
            }
        }
        root.addView(contextCheck)

        val chipsScroll = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
            setPadding(0, dp(4), 0, dp(8))
        }
        val chipsRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        val messagesScroll = ScrollView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(300)
            ).apply {
                bottomMargin = dp(10)
            }
            background = GradientDrawable().apply {
                cornerRadius = dp(20).toFloat()
                setColor(Color.parseColor("#FAF8F2"))
            }
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        val messagesContainer = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
        }
        messagesScroll.addView(messagesContainer)

        fun renderMessages() {
            messagesContainer.removeAllViews()
            if (conversationHistory.isEmpty()) {
                val welcome = TextView(context).apply {
                    text = "Welcome to Open AI Chat (BYOK)!\n\n" +
                        "• Tap '⚙️ Key' at the top right to paste your own API key (Google Gemini, OpenRouter free open-source models like Llama 3.3 / DeepSeek R1, or any OpenAI/Ollama endpoint).\n" +
                        "• Ask questions about the current webpage or any topic below."
                    textSize = 13.5f
                    setTextColor(Color.parseColor("#4B4739"))
                    setPadding(dp(8), dp(8), dp(8), dp(8))
                }
                messagesContainer.addView(welcome)
            } else {
                conversationHistory.forEach { turn ->
                    val isUser = turn.role == "user"
                    val bubble = LinearLayout(context).apply {
                        orientation = LinearLayout.VERTICAL
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply {
                            bottomMargin = dp(10)
                            if (isUser) marginStart = dp(32) else marginEnd = dp(20)
                        }
                        background = GradientDrawable().apply {
                            cornerRadius = dp(16).toFloat()
                            setColor(if (isUser) Color.parseColor("#DDE6C6") else Color.parseColor("#EFECE2"))
                        }
                        setPadding(dp(12), dp(10), dp(12), dp(10))
                    }
                    val roleTv = TextView(context).apply {
                        text = if (isUser) "You" else "✦ Assistant"
                        textSize = 11f
                        paint.isFakeBoldText = true
                        setTextColor(Color.parseColor("#4A5D23"))
                    }
                    val bodyTv = TextView(context).apply {
                        text = turn.text
                        textSize = 14f
                        setTextColor(Color.parseColor("#1E1B13"))
                        setTextIsSelectable(true)
                        setPadding(0, dp(2), 0, 0)
                    }
                    bubble.addView(roleTv)
                    bubble.addView(bodyTv)
                    if (!isUser) {
                        val copyTv = TextView(context).apply {
                            text = "Copy"
                            textSize = 11f
                            setTextColor(Color.parseColor("#4A5D23"))
                            gravity = Gravity.END
                            setPadding(0, dp(4), 0, 0)
                            setOnClickListener {
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("AI Response", turn.text))
                                Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
                            }
                        }
                        bubble.addView(copyTv)
                    }
                    messagesContainer.addView(bubble)
                }
            }
            messagesScroll.post { messagesScroll.fullScroll(View.FOCUS_DOWN) }
        }

        val inputRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(Color.parseColor("#DEDAD0"))
            }
            setPadding(dp(16), dp(6), dp(8), dp(6))
        }

        val promptInput = EditText(context).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            hint = "Ask about this page or anything..."
            setHintTextColor(Color.parseColor("#7C7767"))
            setTextColor(Color.parseColor("#1E1B13"))
            background = null
            textSize = 14.5f
            maxLines = 4
        }

        fun sendPrompt(userText: String) {
            val trimmed = userText.trim()
            if (trimmed.isEmpty()) return
            promptInput.setText("")
            conversationHistory.add(ChatTurn("user", trimmed))
            conversationHistory.add(ChatTurn("assistant", "Thinking..."))
            renderMessages()

            fun executeRequest(pageText: String) {
                val apiKey = ChromePreferences.getAiApiKey(context)
                val provider = ChromePreferences.getAiProvider(context)
                val model = ChromePreferences.getAiModel(context)
                val endpoint = ChromePreferences.getAiEndpoint(context)

                executor.execute {
                    val reply = if (apiKey.isBlank()) {
                        buildOfflinePageSummaryOrGuide(trimmed, currentPageTitle, currentPageUrl, pageText)
                    } else {
                        try {
                            callAiApi(provider, apiKey, model, endpoint, trimmed, currentPageTitle, currentPageUrl, pageText)
                        } catch (e: Exception) {
                            "API Error: ${e.message ?: "Request failed"}. Please verify your API key and model in '⚙️ Key'."
                        }
                    }
                    mainHandler.post {
                        if (conversationHistory.isNotEmpty() && conversationHistory.last().text == "Thinking...") {
                            conversationHistory.removeAt(conversationHistory.lastIndex)
                        }
                        conversationHistory.add(ChatTurn("assistant", reply))
                        renderMessages()
                    }
                }
            }

            if (contextCheck.isChecked && currentWebView != null) {
                currentWebView.evaluateJavascript(
                    "(function(){return document.body ? document.body.innerText.slice(0, 6000) : '';})()"
                ) { rawJsResult ->
                    val cleaned = rawJsResult
                        ?.removeSurrounding("\"")
                        ?.replace("\\n", "\n")
                        ?.replace("\\\"", "\"")
                        ?: ""
                    executeRequest(cleaned)
                }
            } else {
                executeRequest("")
            }
        }

        val quickPrompts = listOf(
            "Summarize this page",
            "Key takeaways",
            "Explain simply",
            "Clear chat"
        )
        quickPrompts.forEach { label ->
            val chip = TextView(context).apply {
                text = label
                textSize = 12.5f
                setTextColor(Color.parseColor("#1E1B13"))
                setPadding(dp(12), dp(6), dp(12), dp(6))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = dp(8) }
                background = GradientDrawable().apply {
                    cornerRadius = dp(16).toFloat()
                    setColor(Color.parseColor("#DEDAD0"))
                }
                setOnClickListener {
                    if (label == "Clear chat") {
                        conversationHistory.clear()
                        renderMessages()
                    } else {
                        sendPrompt(label)
                    }
                }
            }
            chipsRow.addView(chip)
        }
        chipsScroll.addView(chipsRow)
        root.addView(chipsScroll)
        root.addView(messagesScroll)

        val sendBtn = TextView(context).apply {
            text = "Send"
            textSize = 13.5f
            paint.isFakeBoldText = true
            setTextColor(Color.WHITE)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(20).toFloat()
                setColor(Color.parseColor("#4A5D23"))
            }
            setOnClickListener {
                sendPrompt(promptInput.text.toString())
            }
        }

        inputRow.addView(promptInput)
        inputRow.addView(sendBtn)
        root.addView(inputRow)

        renderMessages()

        dialog.setContentView(root)
        dialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        dialog.show()

        if (!initialPrompt.isNullOrBlank()) {
            sendPrompt(initialPrompt)
        }
    }

    fun showApiKeyConfigDialog(context: Context, onSaved: () -> Unit = {}) {
        val density = context.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val layout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(16), dp(24), dp(8))
        }

        val providerLabel = TextView(context).apply {
            text = "AI Provider"
            textSize = 12f
            paint.isFakeBoldText = true
        }
        layout.addView(providerLabel)

        val providers = arrayOf("gemini", "openrouter", "openai")
        val providerNames = arrayOf(
            "Google Gemini API (generativelanguage.googleapis.com)",
            "OpenRouter (Open-Source Llama / DeepSeek / Qwen)",
            "OpenAI / Local Ollama / Custom Compatible Endpoint"
        )
        var selectedProvider = ChromePreferences.getAiProvider(context)
        val spinner = Spinner(context).apply {
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, providerNames)
            setSelection(providers.indexOf(selectedProvider).coerceAtLeast(0))
        }
        layout.addView(spinner)

        val keyLabel = TextView(context).apply {
            text = "Your API Key (Stored locally on device)"
            textSize = 12f
            paint.isFakeBoldText = true
            setPadding(0, dp(12), 0, 0)
        }
        layout.addView(keyLabel)

        val keyInput = EditText(context).apply {
            hint = "Paste API Key (e.g. AIza... or sk-...)"
            setText(ChromePreferences.getAiApiKey(context))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        }
        layout.addView(keyInput)

        val modelLabel = TextView(context).apply {
            text = "Model Name"
            textSize = 12f
            paint.isFakeBoldText = true
            setPadding(0, dp(12), 0, 0)
        }
        layout.addView(modelLabel)

        val modelInput = EditText(context).apply {
            hint = "e.g. gemini-2.5-flash or meta-llama/llama-3.3-70b-instruct:free"
            setText(ChromePreferences.getAiModel(context))
        }
        layout.addView(modelInput)

        val endpointLabel = TextView(context).apply {
            text = "Custom Endpoint URL (Optional)"
            textSize = 12f
            paint.isFakeBoldText = true
            setPadding(0, dp(12), 0, 0)
        }
        layout.addView(endpointLabel)

        val endpointInput = EditText(context).apply {
            hint = "Leave default or enter custom /v1/chat/completions URL"
            setText(ChromePreferences.getAiEndpoint(context))
        }
        layout.addView(endpointInput)

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedProvider = providers[position]
                when (selectedProvider) {
                    "gemini" -> {
                        if (modelInput.text.toString().contains("/") || modelInput.text.toString().startsWith("gpt")) {
                            modelInput.setText("gemini-2.5-flash")
                        }
                        endpointInput.setText("https://generativelanguage.googleapis.com/v1beta/models")
                    }
                    "openrouter" -> {
                        if (!modelInput.text.toString().contains("/")) {
                            modelInput.setText("meta-llama/llama-3.3-70b-instruct:free")
                        }
                        endpointInput.setText("https://openrouter.ai/api/v1/chat/completions")
                    }
                    "openai" -> {
                        if (modelInput.text.toString().startsWith("gemini")) {
                            modelInput.setText("gpt-4o-mini")
                        }
                        endpointInput.setText("https://api.openai.com/v1/chat/completions")
                    }
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        MaterialAlertDialogBuilder(context)
            .setTitle("Configure BYOK AI Assistant")
            .setView(layout)
            .setPositiveButton("Save") { _, _ ->
                ChromePreferences.setAiProvider(context, selectedProvider)
                ChromePreferences.setAiApiKey(context, keyInput.text.toString())
                ChromePreferences.setAiModel(context, modelInput.text.toString())
                ChromePreferences.setAiEndpoint(context, endpointInput.text.toString())
                onSaved()
                Toast.makeText(context, "AI configuration saved", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun buildOfflinePageSummaryOrGuide(
        prompt: String,
        title: String?,
        url: String?,
        pageText: String
    ): String {
        if (pageText.isNotBlank()) {
            val lines = pageText.lines().map { it.trim() }.filter { it.length > 25 }.take(5)
            val wordCount = pageText.split(Regex("\\s+")).size
            val preview = if (lines.isNotEmpty()) lines.joinToString("\n• ", prefix = "• ") else pageText.take(400)
            return "[Local Page Analysis — No API Key Configured Yet]\n" +
                "Page: ${title ?: "Untitled"} (${url ?: ""})\n" +
                "Approx. words: $wordCount\n\n" +
                "Extracted Highlights:\n$preview\n\n" +
                "💡 Tip: Tap '⚙️ Key' at the top right to add your Gemini, OpenRouter, or OpenAI API key for full LLM responses to \"$prompt\"."
        }
        return "No API key is configured yet. Tap '⚙️ Key' in the top right of this sheet to add your own API key (supports Google Gemini, OpenRouter free open-source models, and OpenAI/Ollama endpoints)."
    }

    private fun callAiApi(
        provider: String,
        apiKey: String,
        model: String,
        endpoint: String,
        userPrompt: String,
        pageTitle: String?,
        pageUrl: String?,
        pageText: String
    ): String {
        val contextBlock = if (pageText.isNotBlank()) {
            "Current webpage title: ${pageTitle ?: ""}\nURL: ${pageUrl ?: ""}\nPage content excerpt:\n${pageText.take(4500)}\n\nUser request: $userPrompt"
        } else {
            userPrompt
        }

        return if (provider == "gemini") {
            val cleanBase = endpoint.trimEnd('/')
            val url = "$cleanBase/$model:generateContent?key=$apiKey"
            val payload = JSONObject().apply {
                put("contents", JSONArray().put(
                    JSONObject().apply {
                        put("parts", JSONArray().put(JSONObject().put("text", contextBlock)))
                    }
                ))
            }
            val req = Request.Builder()
                .url(url)
                .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()
            httpClient.newCall(req).execute().use { resp ->
                val bodyStr = resp.body?.string() ?: ""
                if (!resp.isSuccessful) {
                    return "HTTP ${resp.code}: ${bodyStr.take(300)}"
                }
                val json = JSONObject(bodyStr)
                val candidates = json.optJSONArray("candidates")
                val firstPart = candidates?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                    ?.optJSONObject(0)
                firstPart?.optString("text", "No text returned.") ?: "Empty response."
            }
        } else {
            val payload = JSONObject().apply {
                put("model", model)
                val msgs = JSONArray()
                msgs.put(JSONObject().apply {
                    put("role", "system")
                    put("content", "You are a helpful browser AI assistant integrated into an open-source Chrome-style Android browser.")
                })
                msgs.put(JSONObject().apply {
                    put("role", "user")
                    put("content", contextBlock)
                })
                put("messages", msgs)
            }
            val req = Request.Builder()
                .url(endpoint)
                .addHeader("Authorization", "Bearer $apiKey")
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()
            httpClient.newCall(req).execute().use { resp ->
                val bodyStr = resp.body?.string() ?: ""
                if (!resp.isSuccessful) {
                    return "HTTP ${resp.code}: ${bodyStr.take(300)}"
                }
                val json = JSONObject(bodyStr)
                json.optJSONArray("choices")
                    ?.optJSONObject(0)
                    ?.optJSONObject("message")
                    ?.optString("content", "No response content.")
                    ?: "Empty response."
            }
        }
    }
}
