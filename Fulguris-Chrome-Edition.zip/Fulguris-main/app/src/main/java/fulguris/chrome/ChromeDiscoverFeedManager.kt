package fulguris.chrome

import android.content.Context
import android.os.Handler
import android.os.Looper
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import org.jsoup.Jsoup
import org.jsoup.parser.Parser
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

object ChromeDiscoverFeedManager {

    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    fun refreshFeedAsync(context: Context, onComplete: (List<DiscoverArticle>) -> Unit = {}) {
        val appCtx = context.applicationContext
        executor.execute {
            val articles = mutableListOf<DiscoverArticle>()
            val sourcePref = ChromePreferences.getDiscoverSource(appCtx)

            try {
                if (sourcePref == "all") {
                    articles.add(ChromePreferences.getDefaultDiscoverArticles().first())
                }

                when (sourcePref) {
                    "tech_hn" -> {
                        articles.addAll(fetchRssFeed("https://hnrss.org/frontpage?count=8", "Hacker News"))
                    }
                    "wikimedia" -> {
                        articles.addAll(fetchSpaceflightNews())
                        articles.addAll(fetchRssFeed("https://feeds.bbci.co.uk/news/world/rss.xml", "BBC World"))
                    }
                    "custom_rss" -> {
                        val customUrl = ChromePreferences.getCustomRssUrl(appCtx)
                        articles.addAll(fetchRssFeed(customUrl, "Custom RSS"))
                    }
                    else -> {
                        articles.addAll(fetchRssFeed("https://www.livelaw.in/google_feeds.xml", "Live Law").take(3))
                        articles.addAll(fetchSpaceflightNews().take(3))
                        articles.addAll(fetchRssFeed("https://hnrss.org/frontpage?count=5", "Hacker News").take(4))
                    }
                }
            } catch (_: Exception) {
            }

            if (articles.size < 2) {
                articles.clear()
                articles.addAll(ChromePreferences.getDefaultDiscoverArticles())
            } else {
                ChromePreferences.saveCachedDiscoverArticles(appCtx, articles.take(10))
            }

            val finalArticles = ChromePreferences.getCachedDiscoverArticles(appCtx)
            mainHandler.post {
                onComplete(finalArticles)
            }
        }
    }

    private fun fetchSpaceflightNews(): List<DiscoverArticle> {
        val out = mutableListOf<DiscoverArticle>()
        try {
            val req = Request.Builder()
                .url("https://api.spaceflightnewsapi.net/v4/articles/?limit=5")
                .header("User-Agent", "Mozilla/5.0 Chrome/130.0")
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return out
                val body = resp.body?.string() ?: return out
                val results = JSONObject(body).optJSONArray("results") ?: JSONArray()
                for (i in 0 until results.length()) {
                    val item = results.getJSONObject(i)
                    out.add(
                        DiscoverArticle(
                            title = item.optString("title", "Science Update"),
                            url = item.optString("url", "https://spaceflightnewsapi.net"),
                            source = item.optString("news_site", "Spaceflight News"),
                            timeAgo = "${i + 2}h",
                            imageUrl = item.optString("image_url", "landscape_banner"),
                            category = "Science"
                        )
                    )
                }
            }
        } catch (_: Exception) {}
        return out
    }

    private fun fetchRssFeed(rssUrl: String, defaultSource: String): List<DiscoverArticle> {
        val out = mutableListOf<DiscoverArticle>()
        try {
            val req = Request.Builder()
                .url(rssUrl)
                .header("User-Agent", "Mozilla/5.0 Chrome/130.0")
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return out
                val xml = resp.body?.string() ?: return out
                val doc = Jsoup.parse(xml, "", Parser.xmlParser())
                val items = doc.select("item, entry").take(6)
                items.forEachIndexed { idx, el ->
                    val title = el.selectFirst("title")?.text()?.trim() ?: return@forEachIndexed
                    var link = el.selectFirst("link")?.text()?.trim() ?: ""
                    if (link.isEmpty()) {
                        link = el.selectFirst("link")?.attr("href")?.trim() ?: ""
                    }
                    if (link.isEmpty()) return@forEachIndexed
                    val mediaThumb = el.selectFirst("media|thumbnail, media|content, enclosure")?.attr("url") ?: ""
                    out.add(
                        DiscoverArticle(
                            title = title,
                            url = link,
                            source = defaultSource,
                            timeAgo = "${idx + 1}h",
                            imageUrl = mediaThumb.ifEmpty { if (idx % 2 == 0) "tech_thumb" else "landscape_banner" },
                            category = defaultSource
                        )
                    )
                }
            }
        } catch (_: Exception) {}
        return out
    }
}
