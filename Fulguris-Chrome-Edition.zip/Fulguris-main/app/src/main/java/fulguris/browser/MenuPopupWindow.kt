package fulguris.browser

import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.PopupWindow
import androidx.core.view.isVisible
import dagger.hilt.android.EntryPointAccessors
import fulguris.R
import fulguris.activity.WebBrowserActivity
import fulguris.adblock.AbpUserRules
import fulguris.database.bookmark.BookmarkRepository
import fulguris.databinding.MenuCustomBinding
import fulguris.di.HiltEntryPoint
import fulguris.di.configPrefs
import fulguris.extensions.removeFromParent
import fulguris.settings.preferences.UserPreferences
import fulguris.utils.isAppScheme
import fulguris.utils.isSpecialUrl
import timber.log.Timber

class MenuPopupWindow : PopupWindow {

    val bookmarkModel: BookmarkRepository
    val iUserPreferences: UserPreferences
    val abpUserRules: AbpUserRules
    private val menuConfig: MenuConfiguration

    var iBinding: MenuCustomBinding

    private var currentMode: MenuType = MenuType.MainMenu
    private var isIncognito = false

    constructor(
        layoutInflater: LayoutInflater,
        aBinding: MenuCustomBinding = inflate(layoutInflater),
        mode: MenuType = MenuType.MainMenu
    ) : super(aBinding.root, WRAP_CONTENT, WRAP_CONTENT, true) {

        iBinding = aBinding
        currentMode = mode

        isIncognito = (aBinding.root.context as? WebBrowserActivity)?.isIncognito() ?: false

        elevation = 100F
        animationStyle = R.style.AnimationMenu

        setBackgroundDrawable(ColorDrawable())

        val hiltEntryPoint = EntryPointAccessors.fromApplication(
            iBinding.root.context.applicationContext,
            HiltEntryPoint::class.java
        )
        bookmarkModel = hiltEntryPoint.bookmarkRepository
        iUserPreferences = hiltEntryPoint.userPreferences
        abpUserRules = hiltEntryPoint.abpUserRules
        menuConfig = MenuConfiguration(iBinding.root.context)
    }

    private fun scrollToStart(aDelay: Long = 100) {
        iBinding.scrollViewItems.postDelayed(
            {
                if (contentView.context.configPrefs.toolbarsBottom) {
                    iBinding.scrollViewItems.smoothScrollTo(0, iBinding.scrollViewItems.height)
                } else {
                    iBinding.scrollViewItems.smoothScrollTo(0, 0)
                }
            }, aDelay
        )
    }

    fun onMenuItemClicked(menuView: View, onClick: () -> Unit) {
        menuView.setOnClickListener {
            onClick()
        }
    }

    fun setupToolbarLayout() {
        if (contentView == null) return

        val toolbarsBottom = contentView.context.configPrefs.toolbarsBottom

        animationStyle = if (toolbarsBottom) {
            R.style.AnimationMenuBottom
        } else {
            R.style.AnimationMenu
        }

        try {
            if (toolbarsBottom) {
                iBinding.header.removeFromParent()?.addView(iBinding.header)
            } else {
                iBinding.header.removeFromParent()?.addView(iBinding.header, 0)
            }
        } catch (e: IllegalStateException) {
            Timber.w(e, "Header view already has parent during setupToolbarLayout")
        }

        try {
            if (toolbarsBottom) {
                iBinding.scrollViewItems.removeFromParent()?.addView(iBinding.scrollViewItems, 0)
            } else {
                iBinding.scrollViewItems.removeFromParent()?.addView(iBinding.scrollViewItems)
            }
        } catch (e: IllegalStateException) {
            Timber.w(e, "Scroll view already has parent during setupToolbarLayout")
        }
    }

    private fun applyChromeMenuVisibility() {
        iBinding.layoutMenuItemsContainer.isVisible = true

        iBinding.menuItemNewTab.isVisible = true
        iBinding.menuItemIncognito.isVisible = true
        iBinding.menuItemAddTabToGroup.isVisible = true
        iBinding.menuDivider1.isVisible = true

        iBinding.menuItemHistory.isVisible = true
        iBinding.menuItemDeleteBrowsingData.isVisible = true
        iBinding.menuDivider2.isVisible = true

        iBinding.menuItemDownloads.isVisible = true
        iBinding.menuItemBookmarks.isVisible = true
        iBinding.menuItemRecentTabs.isVisible = true
        iBinding.menuDivider3.isVisible = true

        iBinding.menuItemAskGemini.isVisible = true
        iBinding.menuDivider4.isVisible = true

        iBinding.menuItemSettings.isVisible = true
        iBinding.menuItemCustomizeNtp.isVisible = true
        iBinding.menuItemHelpFeedback.isVisible = true

        iBinding.menuItemMainMenu.isVisible = false
        iBinding.menuItemTabMenu.isVisible = false
        iBinding.menuItemSessions.isVisible = false
        iBinding.menuItemOptions.isVisible = false
        iBinding.menuItemPageRequests.isVisible = false
        iBinding.menuItemConsole.isVisible = false
        iBinding.menuItemCookies.isVisible = false
        iBinding.menuItemDomainSettings.isVisible = false
        iBinding.menuItemFullMenu.isVisible = false
        iBinding.menuItemCursor.isVisible = false

        val activity = contentView.context as? WebBrowserActivity
        val tab = activity?.tabsManager?.currentTab
        val isWebPage = tab != null && !tab.url.isSpecialUrl() && !tab.url.isAppScheme()

        iBinding.menuItemShare.isVisible = isWebPage
        iBinding.menuItemFind.isVisible = isWebPage
        iBinding.menuItemTranslate.isVisible = isWebPage
        iBinding.menuItemDesktopMode.isVisible = isWebPage
        iBinding.menuItemDesktopMode.isChecked = tab?.desktopMode ?: false

        val canBack = tab?.canGoBack() ?: false
        val canForward = tab?.canGoForward() ?: false
        iBinding.menuShortcutBack.isEnabled = canBack
        iBinding.menuShortcutBack.alpha = if (canBack) 1.0f else 0.35f
        iBinding.menuShortcutForward.isEnabled = canForward
        iBinding.menuShortcutForward.alpha = if (canForward) 1.0f else 0.35f
        iBinding.menuShortcutBookmarks.isVisible = true
        iBinding.menuShortcutDownload.isVisible = true
        iBinding.menuShortcutRefresh.isVisible = true

        scrollToStart(0)
    }

    fun switchMode(mode: MenuType) {
        currentMode = mode
        applyChromeMenuVisibility()
    }

    fun show(aAnchor: View) {
        applyChromeMenuVisibility()

        val anchorLoc = IntArray(2)
        aAnchor.getLocationInWindow(anchorLoc)

        val gravity = if (contentView.context.configPrefs.toolbarsBottom) {
            Gravity.BOTTOM or Gravity.END
        } else {
            Gravity.TOP or Gravity.END
        }

        val yOffset = if (contentView.context.configPrefs.toolbarsBottom) {
            (contentView.context as WebBrowserActivity).iBinding.root.height - anchorLoc[1] - aAnchor.height
        } else {
            anchorLoc[1] + fulguris.utils.Utils.dpToPx(4F)
        }

        showAtLocation(
            aAnchor,
            gravity,
            fulguris.utils.Utils.dpToPx(8F),
            yOffset
        )

        scrollToStart(0)
    }

    companion object {
        fun inflate(layoutInflater: LayoutInflater): MenuCustomBinding {
            return MenuCustomBinding.inflate(layoutInflater)
        }
    }
}
