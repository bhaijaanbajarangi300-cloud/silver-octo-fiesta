package fulguris

class Entitlement {
    companion object {
        @JvmStatic
        fun maxTabCount(aSponsorship: Sponsorship): Int = 10000
    }
}
