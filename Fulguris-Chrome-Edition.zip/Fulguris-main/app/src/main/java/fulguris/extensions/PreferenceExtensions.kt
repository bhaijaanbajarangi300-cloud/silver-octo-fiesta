/*
 * The contents of this file are subject to the Common Public Attribution License Version 1.0.
 * (the "License"); you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at:
 * https://github.com/Slion/Fulguris/blob/main/LICENSE.CPAL-1.0.
 * The License is based on the Mozilla Public License Version 1.1, but Sections 14 and 15 have been
 * added to cover use of software over a computer network and provide for limited attribution for
 * the Original Developer. In addition, Exhibit A has been modified to be consistent with Exhibit B.
 *
 * Software distributed under the License is distributed on an "AS IS" basis, WITHOUT WARRANTY OF
 * ANY KIND, either express or implied. See the License for the specific language governing rights
 * and limitations under the License.
 *
 * The Original Code is Fulguris.
 *
 * The Original Developer is the Initial Developer.
 * The Initial Developer of the Original Code is Stéphane Lenclud.
 *
 * All portions of the code written by Stéphane Lenclud are Copyright © 2020 Stéphane Lenclud.
 * All Rights Reserved.
 */

package fulguris.extensions

import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.PreferenceGroup


/**
 * Find the first preference whose fragment property matches the template argument.
 * That allows us to fetch preferences from a preference screen without using ids.
 */
inline fun <reified T : PreferenceFragmentCompat?> PreferenceGroup.findPreference(): Preference? {
    return findPreference(T::class.java)
}


/**
 * Find the first preference whose fragment property matches the template argument.
 * That allows us to fetch preferences from a preference screen without using ids.
 */
fun PreferenceGroup.findPreference(aClass: Class<*>): Preference? {
    val preferenceCount: Int = preferenceCount
    for (i in 0 until preferenceCount) {
        val preference: Preference = getPreference(i)
        if (preference.fragment == aClass.name) {
            return preference
        }
    }
    return null
}

/**
 * Set a long click listener on a preference
 * Note: This should be called after the preference is added to the screen
 */
fun Preference.setOnPreferenceLongClickListener(listener: () -> Boolean) {
    // We need to set this on the view holder when it's bound
    // For now, we'll use a workaround with a custom key to store the listener
    // The actual implementation will be in the fragment where we can access the RecyclerView
}


