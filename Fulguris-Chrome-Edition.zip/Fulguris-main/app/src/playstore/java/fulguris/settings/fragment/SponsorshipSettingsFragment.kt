/*
 * The contents of this file are subject to the Common Public Attribution License Version 1.0.
 * (the "License"); you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at:
 * https://github.com/Slion/Fulguris/blob/main/LICENSE.CPAL-1.0.
 * The License is based on the Mozilla Public License Version 1.1, but Sections 14 and 15 have been
 * added to cover use of software over a computer network and provide for limited attribution for
 * the Original Developer. In addition, Exhibit A has been modified to be consistent with Exhibit B.
 *
 * Software distributed under the License is distributed on an "AS IS" basis, WITHOUT WARRANTY OF
 * ANY KIND, either express or implied. See the License for the specific language governing rights
 * and limitations under the License.
 *
 * The Original Code is Fulguris.
 *
 * The Original Developer is the Initial Developer.
 * The Initial Developer of the Original Code is Stéphane Lenclud.
 *
 * All portions of the code written by Stéphane Lenclud are Copyright © 2020 Stéphane Lenclud.
 * All Rights Reserved.
 */

package fulguris.settings.fragment

import fulguris.BuildConfig
import fulguris.R
import fulguris.Sponsorship
import fulguris.settings.preferences.UserPreferences
import fulguris.utils.shareUrl
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.core.content.res.ResourcesCompat
import androidx.preference.Preference
import com.android.billingclient.api.*
import dagger.hilt.android.AndroidEntryPoint
// See: https://stackoverflow.com/a/54188472/3969362
import org.threeten.bp.Period
import timber.log.Timber
import javax.inject.Inject

/**
 * Manage in-app purchases and subscriptions.
 */
@AndroidEntryPoint
class SponsorshipSettingsFragment : AbstractSettingsFragment(),
        PurchasesUpdatedListener,
        BillingClientStateListener {

    val SPONSOR_BRONZE = "sponsor.bronze"
    val SUBS_SKUS = listOf(SPONSOR_BRONZE)

    @Inject internal lateinit var userPreferences: UserPreferences

    // Google Play Store billing client
    private lateinit var playStoreBillingClient: BillingClient

    /**
     * See [AbstractSettingsFragment.titleResourceId]
     */
    override fun titleResourceId(): Int {
        return R.string.settings_contribute
    }

    override fun providePreferencesXmlResource() = R.xml.preference_sponsorship

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        super.onCreatePreferences(savedInstanceState, rootKey)

        // Connect our billing client
        context?.let {
            playStoreBillingClient = BillingClient.newBuilder(it)
                .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
                .setListener(this).build()
        }
    }

    /**
     *
     */
    override fun onResume() {
        super.onResume()
        if (playStoreBillingClient.isReady) {
            // Update our preference screen on resume.
            // That should make sure newly bought stuff are showing after coming back from payment workflow.
            populatePreferenceScreen()
        } else {
            connectToPlayBillingService()
        }
    }

    /**
     *
     */
    override fun onDestroy() {
        super.onDestroy()
        playStoreBillingClient.endConnection()
    }

    /**
     * Start connection with Google Play store billing.
     */
    private fun connectToPlayBillingService(): Boolean {
        Timber.d( "connectToPlayBillingService")
        if (!playStoreBillingClient.isReady) {
            playStoreBillingClient.startConnection(this)
            return true
        }
        return false
    }

    /**
     * Callback from [BillingClient] after opening connection.
     * It might make sense to get [ProductDetails] and [Purchases][Purchase] at this point.
     */
    override fun onBillingSetupFinished(billingResult: BillingResult) {
        when (billingResult.responseCode) {
            BillingClient.BillingResponseCode.OK -> {
                Timber.d( "onBillingSetupFinished successfully")
                populatePreferenceScreen()
            }
            BillingClient.BillingResponseCode.BILLING_UNAVAILABLE -> {
                //Some apps may choose to make decisions based on this knowledge.
                Timber.d( billingResult.debugMessage)
            }
            else -> {
                //do nothing. Someone else will connect it through retry policy.
                //May choose to send to server though
                Timber.d( billingResult.debugMessage)
            }
        }
    }

    /**
     * This method is called when the app has inadvertently disconnected from the [BillingClient].
     * An attempt should be made to reconnect using a retry policy. Note the distinction between
     * [endConnection][BillingClient.endConnection] and disconnected:
     * - disconnected means it's okay to try reconnecting.
     * - endConnection means the [playStoreBillingClient] must be re-instantiated and then start
     *   a new connection because a [BillingClient] instance is invalid after endConnection has
     *   been called.
     **/
    override fun onBillingServiceDisconnected() {
        Timber.d( "onBillingServiceDisconnected")
        connectToPlayBillingService()
    }

    /**
     * Populate preference screen with relevant SKUs.
     * That can include in-apps and subscriptions.
     */
    private fun populatePreferenceScreen() {
        // First remove all subscriptions if any
        var prefCat: x.PreferenceCategory? = preferenceScreen.findPreference(getString(R.string.pref_key_subscriptions_category))
        if (prefCat != null) {
            prefCat.removeAll()
        } else {
            // Create it if not yet present
            addCategorySubscriptions()
        }
        populatePreferenceScreenStaticItems()
        populateSubscriptions()
    }

    /**
     *
     */
    private fun populatePreferenceScreenStaticItems() {
        // Make Fulguris home page preference visible (it's hidden by default in XML)
        findPreference<Preference>("pref_key_fulguris_home")?.isVisible = true

        // Handle share preference programmatically since ACTION_SEND doesn't work from XML
        findPreference<Preference>("pref_key_contribute_share")?.onPreferenceClickListener =
            Preference.OnPreferenceClickListener {
                requireActivity().shareUrl(
                    getString(R.string.url_app_home_page),
                    getString(R.string.locale_app_name),
                    R.string.pref_title_contribute_share
                )
                true
            }
    }

    /**
     * Query our billing client for known subscriptions, then check which ones are currently active
     * to populate our preference screen.
     */
    private fun populateSubscriptions() {
        if (!isSubscriptionSupported()) {
            return
        }
        // Ask servers for our product list
        val productList = SUBS_SKUS.map { sku ->
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(sku)
                .setProductType(BillingClient.ProductType.SUBS)
                .build()
        }
        val params = QueryProductDetailsParams.newBuilder().setProductList(productList).build()
        playStoreBillingClient.queryProductDetailsAsync(params) { billingResult, queryResult ->
            when (billingResult.responseCode) {
                BillingClient.BillingResponseCode.OK -> {
                    Timber.d( "populateSubscriptions OK")
                    // Play Billing Library 8+ returns the details wrapped in a QueryProductDetailsResult
                    val productDetailsList = queryResult.productDetailsList
                    if (productDetailsList.isNotEmpty()) {
                        // We got a valid list of product details for our subscriptions
                        val purchaseParams = QueryPurchasesParams.newBuilder()
                            .setProductType(BillingClient.ProductType.SUBS)
                            .build()
                        playStoreBillingClient.queryPurchasesAsync(purchaseParams) { billingResult, purchases ->
                          if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                              if (purchases.isEmpty()) {
                                  // No valid subscriptions anymore, just downgrade then
                                  userPreferences.sponsorship = Sponsorship.TIN
                              } else {
                                  purchases.forEach {
                                      // Take this opportunity to update our entitlements
                                      if (it.products.contains(SPONSOR_BRONZE)  && it.isAcknowledged) {
                                          userPreferences.sponsorship = Sponsorship.BRONZE
                                      }
                                  }
                              }

                              productDetailsList.forEach { productDetails ->
                                  Timber.d( productDetails.toString())
                                  val pref = x.SwitchPreference(requireContext())
                                  pref.isSingleLineTitle = false
                                  pref.title = productDetails.title
                                  // Extract price and period from subscription offer details
                                  val offerDetails = productDetails.subscriptionOfferDetails?.firstOrNull()
                                  val pricingPhase = offerDetails?.pricingPhases?.pricingPhaseList?.firstOrNull()
                                  val price = pricingPhase?.formattedPrice ?: ""
                                  val period = pricingPhase?.billingPeriod ?: ""
                                  pref.summary = price + formatPeriod(period) + "\n" + productDetails.description
                                  pref.icon = ResourcesCompat.getDrawable(resources, R.drawable.ic_payment, activity?.theme)
                                  // Check if that product is an active subscription
                                  pref.isChecked = purchases.firstOrNull { purchase -> purchase.products.contains(productDetails.productId) && purchase.isAcknowledged } != null
                                  //
                                  pref.onPreferenceChangeListener = Preference.OnPreferenceChangeListener { _, newValue: Any ->
                                      if (newValue == true) {
                                          // User is trying to buy that subscription
                                          // Launch subscription workflow
                                          val productDetailsParamsList = listOf(
                                              BillingFlowParams.ProductDetailsParams.newBuilder()
                                                  .setProductDetails(productDetails)
                                                  .apply { offerDetails?.offerToken?.let { setOfferToken(it) } }
                                                  .build()
                                          )
                                          val purchaseFlowParams = BillingFlowParams.newBuilder()
                                              .setProductDetailsParamsList(productDetailsParamsList)
                                              .build()
                                          activity?.let {
                                              playStoreBillingClient.launchBillingFlow(it, purchaseFlowParams)
                                          }
                                      } else {
                                          // User is trying to cancel subscription maybe
                                          showPlayStoreSubscriptions(productDetails.productId)
                                      }
                                      false
                                  }
                                  pref.order = 0 // We want it at the top

                                  // Fetch subscription category
                                  var prefCat: x.PreferenceCategory? = preferenceScreen.findPreference(getString(R.string.pref_key_subscriptions_category))
                                  if (prefCat == null) {
                                      // Create it if not yet present
                                      prefCat = addCategorySubscriptions()
                                  }
                                  // Add this subscription to our category
                                  prefCat.addPreference(pref)
                              }
                          } else {
                              Timber.e( "queryPurchasesAsync failed")
                              Timber.e( billingResult.debugMessage)
                          }
                        }
                    }
                }
                else -> {
                    Timber.e( "queryProductDetailsAsync failed")
                    Timber.e( billingResult.debugMessage)
                }
            }
        }
    }

    /**
     *
     */
    private fun addCategorySubscriptions() : x.PreferenceCategory {
        val prefCat = x.PreferenceCategory(requireContext())
        prefCat.key = getString(R.string.pref_key_subscriptions_category)
        prefCat.title = getString(R.string.pref_category_subscriptions)
        prefCat.summary = getString(R.string.pref_summary_subscriptions)
        prefCat.order = 0 // We want it at the top
        prefCat.isIconSpaceReserved = false
        preferenceScreen.addPreference(prefCat)
        return prefCat
    }

    /**
     * Open Play Store Subscriptions screen for our application
     */
    private fun showPlayStoreSubscriptions(aSku : String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/account/subscriptions?sku=$aSku&package=${BuildConfig.APPLICATION_ID}")))
        } catch (e: ActivityNotFoundException) {
            // Just ignore
        }
    }


    /**
     * TODO: Improve that I guess
     * Only support one year or one months
     * Otherwise just return an empty string which should still format nicely
     * It just won't specify the period but it is still visible in the payment workflow anyway
     */
    private fun formatPeriod(aPeriod : String) : String {
        var period = Period.parse(aPeriod)
        if (period.years == 1) {
            return resources.getString(R.string.per_year)
        }
        if (period.months == 1) {
            return resources.getString(R.string.per_month)
        }

        return ""
    }

    /**
     * New purchases are coming in from here.
     * We need to acknowledge them.
     */
    override fun onPurchasesUpdated(billingResult: BillingResult, purchases: MutableList<Purchase>?) {
        Timber.d( "onPurchasesUpdated")
        when (billingResult.responseCode) {
            BillingClient.BillingResponseCode.OK -> {
                purchases?.forEach {
                    if (it.purchaseState == Purchase.PurchaseState.PURCHASED) {
                        if (!it.isAcknowledged) {
                            // Just acknowledge our purchase
                            val acknowledgePurchaseParams = AcknowledgePurchaseParams.newBuilder().setPurchaseToken(it.purchaseToken).build()
                            playStoreBillingClient.acknowledgePurchase(acknowledgePurchaseParams) {
                                // TODO: Again what should we do with that?
                                billingResult -> Timber.d( "onAcknowledgePurchaseResponse: $billingResult")
                                when (billingResult.responseCode) {
                                    BillingClient.BillingResponseCode.OK -> {
                                        if (it.products.contains(SPONSOR_BRONZE) ) {
                                            // Purchase acknowledgement was successful
                                            // Update  sponsorship in our settings so that changes can take effect in the app
                                            userPreferences.sponsorship = Sponsorship.BRONZE
                                            // Update our screen to reflect changes
                                            populatePreferenceScreen()
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED -> {
            }
            BillingClient.BillingResponseCode.SERVICE_DISCONNECTED -> {
                connectToPlayBillingService()
            }
            else -> {
                Timber.w(billingResult.debugMessage)
            }
        }
    }


    /**
     * Checks if the user's device supports subscriptions
     */
    private fun isSubscriptionSupported(): Boolean {
        val billingResult =
                playStoreBillingClient.isFeatureSupported(BillingClient.FeatureType.SUBSCRIPTIONS)
        var succeeded = false
        when (billingResult.responseCode) {
            BillingClient.BillingResponseCode.SERVICE_DISCONNECTED -> connectToPlayBillingService()
            BillingClient.BillingResponseCode.OK -> succeeded = true
            else -> Timber.w("isSubscriptionSupported() error: ${billingResult.debugMessage}")
        }
        return succeeded
    }


}
