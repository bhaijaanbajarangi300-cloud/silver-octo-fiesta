@echo off
echo Building Fulguris Chrome Edition APK...
call gradlew.bat assembleSlionsFullFdroidDebug
echo APK built at: appuild\outputspk\slionsFullFdroid\debug