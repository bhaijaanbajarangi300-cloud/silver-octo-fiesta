#!/usr/bin/env bash
set -e
echo "Building Fulguris Chrome Edition APK..."
chmod +x ./gradlew
./gradlew assembleSlionsFullFdroidDebug
echo "APK built at: app/build/outputs/apk/slionsFullFdroid/debug/"
